	if not _G.HoxPopupTest then
		_G.HoxPopupTest = {}
		HoxPopupTest.mod_path = ModPath
		
		HoxPopupTest.options_path = SavePath .. "HoxPopupTest.json"
		HoxPopupTest.options = {} 

		HoxPopupTest.hook_files = HoxPopupTest.hook_files or {
			["lib/units/enemies/cop/copdamage"] = { "test8.lua" }
		}
	end
	
	function HoxPopupTest:Save()
		local file = io.open( self.options_path, "w+" )
		if file then
			file:write( json.encode( self.options ) )
			file:close()
		end
	end

	function HoxPopupTest:Load()
		local file = io.open( self.options_path, "r" )
		if file then
			self.options = json.decode( file:read("*all") )
			file:close()
		else
		log("No previous save found. Creating new using default values")
		local default_file = io.open(self.mod_path .."default_values.json")
			if default_file then
				self.options = json.decode( default_file:read("*all") )
				self:Save()
			end
		end
	end

	if not HoxPopupTest.setup then

		HoxPopupTest:Load()
		HoxPopupTest.setup = true
		log("[HoxPopupTest] Loaded options")
	end

	Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_HoxPopupsTest", function( loc )
		loc:load_localization_file( HoxPopupTest.mod_path .. "Loc/english.json")
	end)

	HoxPopupTest.colors = HoxPopupTest.colors or {
		Color('000000'),
		Color('0000FF'),
		Color('8A2BE2'),
		Color('CD7F32'),
		Color('964B00'),
		Color('00008B'),
		Color('FF8C00'),
		Color('8B0000'),
		Color('9400D3'),
		Color('D4AF37'),
		Color('00FF00'),
		Color('808080'),
		Color('ADD8E6'),
		Color('90EE90'),
		Color('FFB6C1'),
		Color('FFFFE0'),
		Color('FF7F00'),
		Color('FFC0CB'),
		Color('800080'),
		Color('FF0000'),
		Color('C0C0C0'),
		Color('8B00FF'),
		Color('ffffff'),
		Color('FFFF00')
	}
		
	if RequiredScript then
		local requiredScript = RequiredScript:lower()

		if HoxPopupTest.hook_files[requiredScript] then
			for __, file in ipairs(HoxPopupTest.hook_files[requiredScript]) do
				dofile( HoxPopupTest.mod_path .. "lua/" .. file )
			end
		end
	end

	Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_HoxPopupsTest", function( menu_manager )
		
		MenuCallbackHandler.callback_show_damage_popup = function(self, item)
			HoxPopupTest.options.show_damage_popup = (item:value() == "on")
			HoxPopupTest:Save()
		end
		
		MenuCallbackHandler.callback_show_damage_popup_civilian = function(self, item)
			HoxPopupTest.options.show_civilian_damage_popup = (item:value() == "on")
			HoxPopupTest:Save()
		end

		MenuCallbackHandler.callback_show_rainbow_popups = function(self, item)
			HoxPopupTest.options.show_rainbow_popups = (item:value() == "on")
			HoxPopupTest:Save()
		end

		MenuCallbackHandler.callback_show_enemy_health_mul = function(self, item)
			HoxPopupTest.options.show_enemy_health_mul = (item:value() == "on")
			HoxPopupTest:Save()
		end

		MenuCallbackHandler.callback_show_damage_per_hit = function(self, item)
			HoxPopupTest.options.show_damage_per_hit = (item:value() == "on")
			HoxPopupTest:Save()
		end

		MenuCallbackHandler.callback_text_scale = function(self, item)
			HoxPopupTest.options.text_scale = item:value()
			HoxPopupTest:Save()
		 end

		MenuCallbackHandler.callback_hit_display_duration = function(self, item)
			HoxPopupTest.options.hit_display_duration = item:value()
			HoxPopupTest:Save()
		 end
		
		MenuCallbackHandler.callback_hit_chg_per_tick = function(self, item)
			HoxPopupTest.options.hit_chg_per_tick = item:value()
			HoxPopupTest:Save()
		 end
		
		MenuCallbackHandler.callback_fatal_hit_chg_per_tick = function(self, item)
			HoxPopupTest.options.fatal_hit_chg_per_tick = item:value()
			HoxPopupTest:Save()
		 end
		
		 MenuCallbackHandler.callback_damage_vert_offset = function(self, item)
			HoxPopupTest.options.damage_vert_offset = item:value()
			HoxPopupTest:Save()
		 end
		
		MenuCallbackHandler.callback_damage_kill_flash_spd = function(self, item)
			HoxPopupTest.options.damage_kill_flash_spd = item:value()
			HoxPopupTest:Save()
		 end
		
		 MenuCallbackHandler.callback_damage_popup_hit_color = function(self, item)
			HoxPopupTest.options.damage_popup_hit_color = item:value()
			HoxPopupTest:Save()
		 end
		
		MenuCallbackHandler.callback_damage_popup_headshot_flash_color = function(self, item)
			HoxPopupTest.options.damage_popup_headshot_flash_color = item:value()
			HoxPopupTest:Save()
		 end
		
		MenuCallbackHandler.callback_damage_popup_kill_color = function(self, item)
			HoxPopupTest.options.damage_popup_kill_color = item:value()
			HoxPopupTest:Save()
		 end

		HoxPopupTest:Load()

		MenuHelper:LoadFromJsonFile( HoxPopupTest.mod_path .. "Menu/menu.json", HoxPopupTest, HoxPopupTest.options )

	end )