	if not _G.HoxCircleTest then
		_G.HoxCircleTest = {}
		HoxCircleTest.mod_path = ModPath
		
		HoxCircleTest.options_path = SavePath .. "HoxCircleTestV2.json"
		HoxCircleTest.options = {} 

		HoxCircleTest.hook_files = HoxCircleTest.hook_files or {
			["lib/managers/hudmanagerpd2"] = { "test.luac" },
			["lib/units/beings/player/states/playerstandard"] = { "test.luac" },
			["lib/managers/statisticsmanager"] = { "test.luac" },
		}
	end
	
	function HoxCircleTest:Save()
		local file = io.open( self.options_path, "w+" )
		if file then
			file:write( json.encode( self.options ) )
			file:close()
		end
	end

	function HoxCircleTest:Load()
		local file = io.open( self.options_path, "r" )
		if file then
			self.options = json.decode( file:read("*all") )
			file:close()
		else
		log("No previous save found. Creating new using default values")
		local default_file = io.open(self.mod_path .."default_values.json")
			if default_file then
				self.options = json.decode( default_file:read("*all") )
				self:Save()
			end
		end
	end

	if not HoxCircleTest.setup then

		HoxCircleTest:Load()
		
		HoxCircleTest.setup = true
		log("[HoxCircleTest] Loaded options")
	end

	Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_HoxCircleTest", function( loc )
		loc:load_localization_file( HoxCircleTest.mod_path .. "Loc/english.json")
	end)

	HoxCircleTest.colors = HoxCircleTest.colors or {
		Color('000000'),
		Color('0000FF'),
		Color('8A2BE2'),
		Color('CD7F32'),
		Color('964B00'),
		Color('00008B'),
		Color('FF8C00'),
		Color('8B0000'),
		Color('9400D3'),
		Color('D4AF37'),
		Color('00FF00'),
		Color('808080'),
		Color('ADD8E6'),
		Color('90EE90'),
		Color('FFB6C1'),
		Color('FFFFE0'),
		Color('FF7F00'),
		Color('FFC0CB'),
		Color('800080'),
		Color('FF0000'),
		Color('C0C0C0'),
		Color('8B00FF'),
		Color('ffffff'),
		Color('FFFF00')
	}
		
	if RequiredScript then
		local requiredScript = RequiredScript:lower()

		if HoxCircleTest.hook_files[requiredScript] then
			for __, file in ipairs(HoxCircleTest.hook_files[requiredScript]) do
				dofile( HoxCircleTest.mod_path .. "lua/" .. file )
			end
		end
	end

	Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_HoxCircleTest", function( menu_manager )

		MenuCallbackHandler.CloseHoxCircleTestOptions = function(this)
			HoxCircleTest:Save()
			-- _G.HoxEnemySettings.Options:Save()
		end
		
		MenuCallbackHandler.callback_enable_enemy_health_circle = function(self, item)
			HoxCircleTest.options.enable_enemy_health_circle = item:value() == "on" and true or false
			--_G.HoxEnemySettings.Options:Save()
		end
		
		MenuCallbackHandler.callback_ignore_civilian_health = function(self, item)
			HoxCircleTest.options.ignore_civilian_health = item:value() == "on" and true or false
			--HoxCircleTest:Save()
		end
		
		MenuCallbackHandler.callback_ignore_team_ai_health = function(self, item)
			HoxCircleTest.options.ignore_team_ai_health = item:value() == "on" and true or false
			--HoxCircleTest:Save()
		end

		MenuCallbackHandler.callback_show_vehicle = function(self, item)
			HoxCircleTest.options.show_vehicle = item:value() == "on" and true or false
			--HoxCircleTest:Save()
		end

		MenuCallbackHandler.callback_show_enemy_health_mul = function(self, item)
			HoxCircleTest.options.show_enemy_health_mul = item:value() == "on" and true or false
			-- _G.HoxEnemySettings.Options:Save()
		end
		
		MenuCallbackHandler.callback_enemy_health_size = function(self, item)
			HoxCircleTest.options.enemy_health_size = item:value()
			--_G.HoxEnemySettings.Options:Save()
		end
		
		MenuCallbackHandler.callback_enemy_text_size = function(self, item)
			HoxCircleTest.options.enemy_text_size = item:value()
			--_G.HoxEnemySettings.Options:Save()
		end
		
		MenuCallbackHandler.callback_enemy_health_vertical_offset = function(self, item)
			HoxCircleTest.options.enemy_health_vertical_offset = item:value()
			--_G.HoxEnemySettings.Options:Save()
		end
		
		MenuCallbackHandler.callback_enemy_health_horizontal_offset = function(self, item)
			HoxCircleTest.options.enemy_health_horizontal_offset = item:value()
			--_G.HoxEnemySettings.Options:Save()
		end

		MenuCallbackHandler.callback_enemy_health_hit_color = function(self, item)
			HoxCircleTest.options.enemy_health_hit_color = item:value()
			-- _G.HoxEnemySettings.Options:Save()
		 end
		
		MenuCallbackHandler.callback_enemy_health_kill_color = function(self, item)
			HoxCircleTest.options.enemy_health_kill_color = item:value()
			-- _G.HoxEnemySettings.Options:Save()
		 end

		HoxCircleTest:Load()
		-- _G.HoxEnemySettings.Options:Load()

		MenuHelper:LoadFromJsonFile( HoxCircleTest.mod_path .. "Menu/menu.json", HoxCircleTest, HoxCircleTest.options )

	end )
		