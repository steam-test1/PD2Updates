function PDTHMenuFix:init()
end