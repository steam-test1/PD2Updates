if not HoloInfo.options.tape_loop_enable then return end

local original_update = SecurityCamera.update
local original__upd_detection = SecurityCamera._upd_detection
local original_set_detection_enabled = SecurityCamera.set_detection_enabled
local original_can_apply_tape_loop = SecurityCamera.can_apply_tape_loop
local original__start_tape_loop_by_upgrade_level = SecurityCamera._start_tape_loop_by_upgrade_level
local original__request_start_tape_loop_by_upgrade_level = SecurityCamera._request_start_tape_loop_by_upgrade_level
local original__clbk_tape_loop_expired = SecurityCamera._clbk_tape_loop_expired
local original_sync_net_event = SecurityCamera.sync_net_event
local original_generate_cooldown = SecurityCamera.generate_cooldown
local original_set_update_enabled = SecurityCamera.set_update_enabled
local original_deactivate_tape_loop = SecurityCamera._deactivate_tape_loop
local original_destroy = SecurityCamera.destroy

if not tweak_data then
	return
end

tweak_data.tab_screen_timers = {}
tweak_data.tab_screen_timers.tape_loop = nil
tweak_data.tape_loop_name = "Tape Loop"
tweak_data.tape_loop_expire_color = Color("700000")
tweak_data.tape_loop_restart_flash_period = 3 --larger numbers = faster flashing

function SecurityCamera:update(unit, t, dt, ...)
	if self._tape_loop_timer and not self._suspicion then
		if self._tape_loop_end_t then
			self._tape_loop_total = self._tape_loop_total or (self._tape_loop_end_t - t)
			self._tape_loop_timer:set_completion(self._tape_loop_end_t - t, self._tape_loop_total)
		elseif self._tape_loop_timer and self._tape_loop_restarting_t then
			self._tape_loop_total = self._tape_loop_total or (self._tape_loop_restarting_t - t)
			self._tape_loop_timer:set_completion(self._tape_loop_restarting_t - t, self._tape_loop_total)
		end
	end
	return original_update(self, unit, t, dt, ...)
end

function SecurityCamera:_upd_detection(...)
	if self._tape_loop_timer then
		managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		self._tape_loop_timer = nil
	end
	return original__upd_detection(self, ...)
end

function SecurityCamera:set_detection_enabled(state, ...)
	self._camera_on = state
	if not state and self._tape_loop_timer then
		managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		self._tape_loop_timer = nil
	end
	return original_set_detection_enabled(self, state, ...)
end

function SecurityCamera:can_apply_tape_loop(...)
	if Network:is_server() and not self._camera_on then
		return false
	end
	return original_can_apply_tape_loop(self, ...)
end

function SecurityCamera:_start_tape_loop_hud_timer()
	if not self._alarm_sound and (not Network:is_server() or self._camera_on) then
		if self._tape_loop_timer then
			managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		end
		self._tape_loop_timer = managers.hud:add_hud_timer(tweak_data.tab_screen_timers.tape_loop, tweak_data.tape_loop_name, { tweak_name = "tape_loop", complete_color = tweak_data.tape_loop_expire_color, flash_period = tweak_data.tape_loop_restart_flash_period})
	end
end

function SecurityCamera:_start_tape_loop_by_upgrade_level(...)
	self:_start_tape_loop_hud_timer()
	return original__start_tape_loop_by_upgrade_level(self, ...)
end

function SecurityCamera:_request_start_tape_loop_by_upgrade_level(...)
	if Network:is_server() and not self._camera_on then
		return
	end
	self:_start_tape_loop_hud_timer()
	return original__request_start_tape_loop_by_upgrade_level(self, ...)
end

function SecurityCamera:_clbk_tape_loop_expired(...)
	original__clbk_tape_loop_expired(self, ...)
	self._tape_loop_total = nil
	if self._tape_loop_timer then
		if not managers.groupai:state():whisper_mode() then
			managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
			self._tape_loop_timer = nil
		else
			self._tape_loop_timer:set_jammed(true)
		end
	end
end

function SecurityCamera:sync_net_event(event_id)
	if not Network:is_server() then
		if event_id == self._NET_EVENTS.start_tape_loop_1 or event_id == self._NET_EVENTS.start_tape_loop_2 then
			self._tape_loop_end_t = TimerManager:game():time() + tweak_data.upgrades.values.player.tape_loop_duration[event_id - (self._NET_EVENTS.start_tape_loop_1 - 1)]
			self:set_update_enabled(true)
		elseif event_id == self._NET_EVENTS.request_start_tape_loop_1 or event_id == self._NET_EVENTS.request_start_tape_loop_2 then
			self._tape_loop_end_t = TimerManager:game():time() + tweak_data.upgrades.values.player.tape_loop_duration[event_id - (self._NET_EVENTS.request_start_tape_loop_1 - 1)]
			self:set_update_enabled(true)
		end
	end
	return original_sync_net_event(self, event_id)
end

function SecurityCamera:generate_cooldown(...)
	if self._tape_loop_timer then
		managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		self._tape_loop_timer = nil
	end
	return original_generate_cooldown(self, ...)
end

function SecurityCamera:set_update_enabled(status, ...)
	if not status and self._tape_loop_timer and (not Network:is_server() or (Network:is_server() and not managers.groupai:state():whisper_mode())) then
		managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		self._tape_loop_timer = nil
	end
	return original_set_update_enabled(self, status, ...)
end

function SecurityCamera:_deactivate_tape_loop(...)
	if self._tape_loop_timer then
		managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		self._tape_loop_timer = nil
	end
	return original_deactivate_tape_loop(self, ...)
end

function SecurityCamera:destroy(...)
	if self._tape_loop_timer then
		managers.hud:del_hud_timer(tweak_data.tab_screen_timers.tape_loop, self._tape_loop_timer)
		self._tape_loop_timer = nil
	end
	return original_destroy(self, ...)
end
