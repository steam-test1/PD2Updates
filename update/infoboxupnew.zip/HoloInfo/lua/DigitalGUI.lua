if not HoloInfo.options.Digitaltimer_enable then return end

local original_init = DigitalGui.init
local original_timer_start_count_down = DigitalGui.timer_start_count_down
local original_timer_set = DigitalGui.timer_set
local original_timer_pause = DigitalGui.timer_pause
local original_timer_resume = DigitalGui.timer_resume
local original__update_timer_text = DigitalGui._update_timer_text
local original__timer_stop = DigitalGui._timer_stop
local original_destroy = DigitalGui.destroy

if not tweak_data then
	return
end

tweak_data.tab_screen_timers = {
	drill = nil, 
	lance = nil, 
	lance_upgrade = nil, 
	hack_suburbia = nil, 
	uload_database = nil, 
	uload_database_jammed = nil,
	gen_int_saw = nil
 }
tweak_data.tab_screen_timers.digitalgui = nil
tweak_data.timer_text_color = Color.white
tweak_data.timer_complete_color = Color.green
tweak_data.timer_broken_flash = Color.red
tweak_data.timer_flash_speed = 1

overrides = {
	"135076",							-- Lab rats cloaker safe 2
	"135246",							-- Lab rats cloaker safe 3
	"135247",							-- Lab rats cloaker safe 4
	"145557",							-- Safehouse Killhouse Timer
	"145676",							-- Safehouse Hockeygame Timer
	"400003",							-- Prison Nightmare Big Loot timer
	"100007",							--Cursed kill room timer
	"100888",							--Cursed kill room timer
	"100889",							--Cursed kill room timer
	"100891",							--Cursed kill room timer
	"100892",							--Cursed kill room timer
	"100878",							--Cursed kill room timer
	"100176",							--Cursed kill room timer
	"100177",							--Cursed kill room timer
	"100029",							--Cursed kill room timer
	"141821",							--Cursed kill room safe 1 timer
	"141822",							--Cursed kill room safe 1 timer
	"140321",							--Cursed kill room safe 2 timer
	"140322",							--Cursed kill room safe 2 timer
	"139821",							--Cursed kill room safe 3 timer
	"139822",							--Cursed kill room safe 3 timer
	"141321",							--Cursed kill room safe 4 timer
	"141322",							--Cursed kill room safe 4 timer
	"140821",							--Cursed kill room safe 5 timer
	"140822",							--Cursed kill room safe 5 timer
}

DigitalGui._timers = {}

function DigitalGui:init(...)
	local unit = ...
	self._in_tab_screen = tweak_data.tab_screen_timers.digitalgui
	DigitalGui._timers[unit:key()] = self
	return original_init(self, ...)
end

function DigitalGui:check_is_dupe()
	if self._isDupe then
		return true
	end
	for k,v in pairs(DigitalGui._timers) do
		if k == self._unit:key() and overrides[k] then
			return false
		elseif ((Network:is_server() and v._timer == self._timer) or (Network:is_client() and string.format("%.1f", v._timer) == string.format("%.1f", self._timer))) then
			v._isDupe = true
			if v._hud_timer then
				managers.hud:del_hud_timer(v._in_tab_screen, v._hud_timer)
				v._hud_timer = nil
			end
			return false
		end
	end
	return false
end

function DigitalGui:timer_start_count_down( ... )
	if not self:check_is_dupe() then
		self._hud_timer = self._hud_timer or managers.hud:add_hud_timer(self._in_tab_screen, tweak_data.timer_name_map.digitalgui, {tweak_name = "digitalgui"})
	end
	original_timer_start_count_down(self, ...)
end

function DigitalGui:timer_set( ... )
	local timer = ...
	if not self._total_time or self._total_time < timer then
		self._total_time = timer
	end
	original_timer_set(self, ...)
end

function DigitalGui:timer_pause(...)
	if self._hud_timer then
		managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
		self._hud_timer = nil
	end
	original_timer_pause(self, ...)
end

function DigitalGui:timer_resume(...)
	if not self:check_is_dupe() then
		self._hud_timer = self._hud_timer or managers.hud:add_hud_timer(self._in_tab_screen, tweak_data.timer_name_map.digitalgui, {tweak_name = "digitalgui"})
	end
	original_timer_resume(self, ...)
end

function DigitalGui:_update_timer_text(...)
	if not self._hud_timer or self:check_is_dupe() then
		return original__update_timer_text(self, ...)
	end
	original__update_timer_text(self, ...)
	if not self._total_time or self._total_time < self._timer then
		self._total_time = self._timer
	end
	if self._hud_timer then
		if self._timer <= 0.19 then
			managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
			self._hud_timer = nil
		else
			self._hud_timer:set_completion(self._timer, self._total_time)
		end
	end
end

function DigitalGui:_timer_stop(...)
	if self._hud_timer then
		managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
		self._hud_timer = nil
	end
	original__timer_stop(self, ...)
end

function DigitalGui:destroy(...)
	DigitalGui._timers[self._unit:key()] = nil
	original_destroy(self, ...)
end
