if not HoloInfo.options.Drilltimer_enable then return end

local original__start = TimerGui._start
local original_done = TimerGui.done
local original_destroy = TimerGui.destroy
local original_update = TimerGui.update
local original__set_jammed = TimerGui._set_jammed
local original_set_background_icons = TimerGui.set_background_icons

if not tweak_data then
	return
end

tweak_data.timer_name_map = { 
	lance = "thermal drill", 
	lance_upgrade = "thermal drill", 
	uload_database = "upload", 
	uload_database_jammed = "upload",
	votingmachine2 = "vote rigging", 
	hack_suburbia = "hacking",
	digitalgui = "Timelock", 
	drill = "drill", 
	huge_lance = "The Beast",
	gen_int_saw = "saw",
	apartment_saw = "saw",
	hack_suburbia_axis = "hacking"
}
tweak_data.tab_screen_timers = { 
	drill = nil, 
	lance = nil, 
	lance_upgrade = nil, 
	hack_suburbia = nil, 
	uload_database = nil, 
	uload_database_jammed = nil
}
tweak_data.timer_text_color = Color.white
tweak_data.timer_complete_color = Color.green
tweak_data.timer_broken_flash = Color.red
tweak_data.timer_flash_speed = 1

tweak_data.drill_autorestart_flash = Color("AA00FF")
tweak_data.drill_silent_basic = Color("70E5FF")
tweak_data.drill_silent_aced = Color("003CFF")

function TimerGui:_create_hud_timer()
	if self._hud_timer then
		return
	end
	local name = " "
	local tweak_name = ""
	self._in_tab_screen = false
	if self._unit and self._unit.interaction and self._unit:interaction() then
		tweak_name = self._unit:interaction().tweak_data
		name = tweak_data.timer_name_map[ tweak_name ] or (tweak_name and tweak_name:gsub("_", " ")) or " "
		self._in_tab_screen = tweak_data.tab_screen_timers[ tweak_name ]
	end
	self._hud_timer = managers.hud:add_hud_timer(self._in_tab_screen, name, {
		tweak_name = tweak_name, 
		complete_color = tweak_data.timer_complete_color, 
		text_color = tweak_data.timer_text_color, 
		timer_flash = tweak_data.timer_broken_flash, 
		text_color = tweak_data.timer_text_color, 
		text_flash = tweak_data.timer_broken_flash, 
		flash_period = tweak_data.timer_flash_speed
	})
	if self._hud_timer then
		self._hud_timer:set_visible(false)
	end
end

function TimerGui:_start(...)
	self:_create_hud_timer()
	if self._hud_timer then
		self._hud_timer:set_visible(true)
	end
	original__start(self, ...)
end

function TimerGui:done()
	original_done(self)
	if self._hud_timer then
		managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
		self._hud_timer = nil
	end
end

function TimerGui:destroy(...)
	original_destroy(self, ...)
	if self._hud_timer then
		managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
		self._hud_timer = nil
	end
end

function TimerGui:update(...)
	original_update(self, ...)
	if not self._jammed and self._hud_timer then
		self._hud_timer:set_completion(self._time_left, self._timer)
	end
end

function TimerGui:_set_jammed(...)
	original__set_jammed(self, ...)
	if self._hud_timer then
		self._hud_timer:set_jammed(self._jammed)
	end
end

function TimerGui:set_background_icons(bg_icons, ...)
	self:_create_hud_timer()
	if not self._hud_timer then
		return
	end
	for _,v in pairs(bg_icons) do
		if v.texture:find("drillgui_icon_restarter") and v.color == self:get_upgrade_icon_color("upgrade_color_1") and self._unit:base() and self._unit:base()._autorepair then
			self._hud_timer:set_timer_flash(tweak_data.drill_autorestart_flash)
			self._hud_timer:set_text_flash(tweak_data.drill_autorestart_flash)
		elseif v.texture:find("drillgui_icon_silent") then
			if v.color == self:get_upgrade_icon_color("upgrade_color_1") then
				self._hud_timer:set_text_color(tweak_data.drill_silent_basic)
			elseif v.color == self:get_upgrade_icon_color("upgrade_color_2") then
				self._hud_timer:set_text_color(tweak_data.drill_silent_aced)
			end
		end
	end
	original_set_background_icons(self, bg_icons, ...)
end
