if HoloInfo.options.ECMtimer_enable then return end

HoloInfo:clone(ECMJammerBase)

tweak_data.ecm_name = "ECM"
tweak_data.ecm_feedback_name = "ECM\n Feedback"
tweak_data.ecm_feedback_flash = Color.red -- This sets the colour for the timer to flash while feedback is active
tweak_data.ecm_text_color = Color.white -- This sets the colour to display for the ECM text
tweak_data.ecm_expire_color = Color.red -- This sets the colour the timer text will turn as it gets closer to running out

function ECMJammerBase:init(...)
	self.old.init(self, ...)
	self._in_tab_screen = tweak_data.tab_screen_timers.ecm_jammer or false
	self._hud_timer = self._hud_timer or managers.hud:add_hud_timer(self._in_tab_screen, tweak_data.ecm_name, {
		tweak_name = "ecm_jammer", 
		timer_complete = tweak_data.ecm_expire_color, 
		timer_flash = tweak_data.ecm_feedback_flash, 
		text_color = tweak_data.ecm_text_color, 
		text_flash = tweak_data.ecm_feedback_flash
	})
	if self._hud_timer then
		self._hud_timer:set_visible(false)
	end
end

function ECMJammerBase:set_active(active, ...)
	self.old.set_active(self, active, ...)
	if active and self._hud_timer then
		self._hud_timer:set_visible(true)
	end
end

function ECMJammerBase:_set_feedback_active(state, ...)
	state = state or false
	if state == self._feedback_active then
		return
	end
	self.old._set_feedback_active(self, state, ...)
	if self._feedback_active then
		if self._hud_timer then
			self._hud_timer:set_name_text(tweak_data.ecm_feedback_name)
			self._hud_timer:set_jammed(true)
		end
	else
		if self._hud_timer then
			self._hud_timer:set_name_text(tweak_data.ecm_name)
			self._hud_timer:set_jammed(false)
		end
	end
end

function ECMJammerBase:check_battery(...)
	self.old.check_battery(self, ...)
	if self._battery_life <= 0 and self._hud_timer then
		managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
		self._hud_timer = nil
	elseif self._hud_timer then
		self._hud_timer:set_completion(self._battery_life, self._max_battery_life)
	end
end

function ECMJammerBase:destroy(...)
	self.old.destroy(self, ...)
	if self._hud_timer then
		managers.hud:del_hud_timer(self._in_tab_screen, self._hud_timer)
		self._hud_timer = nil
	end
end
