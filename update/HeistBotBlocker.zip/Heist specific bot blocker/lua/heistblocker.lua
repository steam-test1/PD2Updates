-- Is there any point in me including the multiple day jobs in this anymore since Overkill added the feature to keep the same bots across all days? Surely all you would need to do is define which bots appear on day 1 then let the game do the rest. I don't know.
-- Yes dummy for escapes. Take 'em out!
-- Anyway, moving on...

local blocked_characters_per_heist =
{
	---------------------
	--     Safehouse Raid  --
	---------------------
    
	chill_combat =
	{
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},
	
	---------------------
	--    Jewelry Store     --
	---------------------
	
	jewelry_store =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
							
	},
	
	---------------------
	--    Bank Heists - Apparently Sydney just shows up to one of these so why not     --
	---------------------
	
	branchbank =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Diamond Store     --
	---------------------
	
	family =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Car Shop     --
	---------------------
	
	cage =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'blocked',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Cook Off     --
	---------------------
	
	rat =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'blocked',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Transport: Crossroads     --
	---------------------
	
	arm_cro =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Transport: Downtown     --
	---------------------
	
	arm_hcm =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Transport: Harbor     --
	---------------------
	
	arm_fac =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Transport: Underpass     --
	---------------------
	
	arm_und =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Transport: Park     --
	---------------------
	
	arm_par =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Transport: Train     --
	---------------------
	
	arm_for =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    GO Bank     --
	---------------------
	
	roberts =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Shadow Raid     --
	---------------------
	
	kosugi =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Art Gallery     --
	---------------------
	
	gallery =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Alesso     --
	---------------------
	
	arena =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Big Bank     --
	---------------------
	
	big =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Hotline Miami     --
	---------------------
	
	mia_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	mia_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Hoxton Breakout  - Which can stay but only because Hoxton refers to him)  --
	---------------------
	
	hox_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	hox_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    The Diamond     --
	---------------------
	
	mus =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'blocked',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Hoxton Revenge     --
	---------------------
	
	hox_3 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Golden Grin Casino     --
	---------------------
	
	kenaz =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Watchdogs     --
	---------------------
	
	watchdogs_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	watchdogs_1_night =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	watchdogs_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	watchdogs_2_day =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Firestarter     --
	---------------------
	
	firestarter_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	firestarter_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	firestarter_3 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Rats    --
	---------------------
	
	alex_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	alex_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	alex_3 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Framing Frame   --
	---------------------
	
	framing_frame_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	framing_frame_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	framing_frame_3 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Big Oil  --
	---------------------
	
	welcome_to_the_jungle_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	welcome_to_the_jungle_1_night =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	welcome_to_the_jungle_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Election Day  --
	---------------------
	
	election_day_1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	election_day_2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	election_day_3 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	election_day_3_skip1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	election_day_3_skip2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Biker Heist - Using the trailer guys for this --
	---------------------
	
	born =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	chew =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Four Stores  --
	---------------------
	
	four_stores =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Mallcrasher  --
	---------------------
	
	mallcrasher =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Nightclub  --
	---------------------
	
	nightclub =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Ukrainian Job  --
	---------------------
	
	ukrainian_job =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    White Xmas  --
	---------------------
	
	pines =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Meltdown  --
	---------------------
	
	shoutout_raid =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Aftershock    --
	---------------------
	
	jolly =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Santas Workshop    --
	---------------------
	
	cane =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Goat Simulator   --
	---------------------
	
	peta =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	peta2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Stealing Xmas   --
	---------------------
	
	moon =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    The Bomb: Dockyard     --
	---------------------
	
	crojob2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'blocked',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    The Bomb: Forest     --
	---------------------
	
	crojob3 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'blocked',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	crojob3_night =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'blocked',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Scarface Heist - Trailer guys (and gal) again --
	---------------------
	
	friend =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    First World Bank   --
	---------------------
	
	red2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Slaughterhouse   --
	---------------------
	
	dinner =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Counterfeit   --
	---------------------
	
	pal =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Undercover   --
	---------------------
	
	man =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Panic Room   --
	---------------------
	
	flat =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Lab Rats     --
	---------------------
	
	nail =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Safehouse Nightmare   --
	---------------------
	
	haunted =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Prison Nightmare     --
	---------------------
	
	help =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Beneath the Mountain     --
	---------------------
	
	pbr =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Birth of Sky     --
	---------------------
	
	pbr2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Boiling Point    --
	---------------------
	
	mad =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Murky Station    --
	---------------------
	
	dark =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Brooklyn 10-10    --
	---------------------
	
	spa =
	{ 
							russian = 'blocked',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    The Yacht Heist    --
	---------------------
	
	fish =
	{ 
		russian = 'blocked',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'allowed',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Heat Street    --
	---------------------
	
	run =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Green Bridge    --
	---------------------
	
	glace =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'blocked',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--    Diamond Heist    --
	---------------------
	
	dah =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'blocked',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Reservoir Dogs Heist Day 1    --
	---------------------
	
	rvd1 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Reservoir Dogs Heist Day 2    --
	---------------------
	
	rvd2 =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Cursed Kill Room    --
	---------------------
	
	hvh =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Alaskan Deal    --
	---------------------
	
	wwh =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Brooklyn Bank    --
	---------------------
	
	brb =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Breakin' Feds    --
	---------------------
	
	tag =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Henry's Rock    --
	---------------------
	
	des =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   No Mercy    --
	---------------------
	
	nmh =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'blocked',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Shacklethorne Auction    --
	---------------------
	
	sah =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   The White House    --
	---------------------
	
	vit =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   Hell's Island    --
	---------------------
	
	bph =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'allowed',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'allowed',	-- Clover
		dragan = 'allowed',		-- Dragan
		jacket = 'allowed',		-- Jacket
		bonnie = 'allowed',		-- Bonnie
		sokol = 'allowed',		-- Sokol
		dragon = 'allowed',		-- Jiro
		bodhi = 'allowed',		-- Bodhi
		jimmy = 'allowed',		-- Jimmy
		sydney = 'allowed',		-- Sydney
		wild = 'allowed',		-- Rust
		chico = 'allowed',		-- Scarface
		max = 'allowed',		-- Sangres
		joy = 'allowed',		-- Joy
		myh = 'allowed',		-- Duke
		ecp_female = 'allowed',	-- Hila
		ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   Border Crossing    --
	---------------------
	
	mex =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   Border Crystals    --
	---------------------
	
	mex_cooking =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   San Martin Bank    --
	---------------------
	
	bex =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   San Martin Bank    --
	---------------------
	
	bex =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	---------------------
	--   Breakfast In Tijuana    --
	---------------------
	
	pex =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'allowed',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'allowed',	-- Clover
							dragan = 'allowed',		-- Dragan
							jacket = 'allowed',		-- Jacket
							bonnie = 'allowed',		-- Bonnie
							sokol = 'allowed',		-- Sokol
							dragon = 'allowed',		-- Jiro
							bodhi = 'allowed',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'allowed',		-- Sydney
							wild = 'allowed',		-- Rust
							chico = 'allowed',		-- Scarface
							max = 'allowed',		-- Sangres
							joy = 'allowed',		-- Joy
							myh = 'allowed',		-- Duke
							ecp_female = 'allowed',	-- Hila
							ecp_male = 'allowed'	-- Ethan
	},

	-- Holdout/Custom Heists
	
	---------------------
	--   The Diamond (Holdout)    --
	---------------------
	
	skm_mus =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
							spanish = 'blocked',	-- Chains
							american = 'allowed',	-- Houston
							jowi = 'blocked',		-- John Wick
							old_hoxton = 'allowed',	-- Hoxton
							female_1 = 'allowed',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--   First World Bank (Holdout)    --
	---------------------
	
	skm_red2 =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'blocked',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
},

	---------------------
	--   Heat Street (Holdout)    --
	---------------------
	
	skm_run =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'blocked',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'blocked',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'allowed',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
},

	---------------------
	--   Watchdogs (Holdout)    --
	---------------------
	
	skm_watchdogs_stage2 =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Go Bank v2 (ResMod)    --
	---------------------
	
	roberts_v2 =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Firestarter Day 1 (ResMod)    --
	---------------------
	
	firestarter_1_res =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Firestarter Day 2 (ResMod)    --
	---------------------
	
	firestarter_2_res =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Firestarter Day 3 (ResMod)    --
	---------------------
	
	firestarter_3_res =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},
	
	---------------------
	--   Ukrainian Job (ResMod)    --
	---------------------
	
	ukrainian_job_res =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Heat Street (ResMod)    --
	---------------------
	
	run_res =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--    Rats (ResMod)   --
	---------------------
	
	alex_1_res =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	alex_2_res =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},
	
	alex_3_res =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'allowed',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'allowed',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'blocked',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'blocked',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Heat Street (Holdout)    --
	---------------------
	
	skm_heat_street =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Watchdogs (Holdout)    --
	---------------------
	
	skm_watchdogs_stage2 =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Watchdogs (Holdout)    --
	---------------------
	
	skm_watchdogs_stage2 =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Overgrill (Holdout)    --
	---------------------
	
	skmc_ovengrill =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   The Yacht (Holdout)    --
	---------------------
	
	skmc_ovengrill =
	{ 
		russian = 'blocked',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'allowed',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Boiling Point (Holdout)    --
	---------------------
	
	skmc_mad =
	{ 
							russian = 'allowed',	-- Dallas
							german = 'blocked',		-- Wolf
                            spanish = 'allowed',	-- Chains
                            american = 'blocked',	-- Houston
                            jowi = 'blocked',		-- John Wick
                            old_hoxton = 'allowed',	-- Hoxton
                            female_1 = 'blocked',	-- Clover
							dragan = 'blocked',		-- Dragan
							jacket = 'blocked',		-- Jacket
							bonnie = 'blocked',		-- Bonnie
							sokol = 'blocked',		-- Sokol
							dragon = 'blocked',		-- Jiro
							bodhi = 'blocked',		-- Bodhi
							jimmy = 'allowed',		-- Jimmy
							sydney = 'blocked',		-- Sydney
							wild = 'blocked',		-- Rust
							chico = 'blocked',		-- Scarface
							max = 'blocked',		-- Sangres
							joy = 'blocked',		-- Joy
							myh = 'blocked',		-- Duke
							ecp_female = 'blocked',	-- Hila
							ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Golden Grin Casino (Holdout)    --
	---------------------
	
	skm_cas =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'blocked',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'allowed',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Big Bank (Holdout)    --
	---------------------
	
	skm_big2 =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Mallcrasher (Holdout)    --
	---------------------
	
	skm_mallcrasher =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   Alesso (Holdout)    --
	---------------------
	
	skm_arena =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'blocked',		-- John Wick
		old_hoxton = 'blocked',	-- Hoxton
		female_1 = 'blocked',	-- Clover
		dragan = 'blocked',		-- Dragan
		jacket = 'blocked',		-- Jacket
		bonnie = 'blocked',		-- Bonnie
		sokol = 'blocked',		-- Sokol
		dragon = 'blocked',		-- Jiro
		bodhi = 'blocked',		-- Bodhi
		jimmy = 'blocked',		-- Jimmy
		sydney = 'blocked',		-- Sydney
		wild = 'blocked',		-- Rust
		chico = 'blocked',		-- Scarface
		max = 'blocked',		-- Sangres
		joy = 'blocked',		-- Joy
		myh = 'blocked',		-- Duke
		ecp_female = 'blocked',	-- Hila
		ecp_male = 'blocked'	-- Ethan
	},

	---------------------
	--   San Martin Bank (Holdout)    --
	---------------------
	
	skm_bex =
	{ 
		russian = 'allowed',	-- Dallas
		german = 'allowed',		-- Wolf
		spanish = 'allowed',	-- Chains
		american = 'allowed',	-- Houston
		jowi = 'allowed',		-- John Wick
		old_hoxton = 'allowed',	-- Hoxton
		female_1 = 'allowed',	-- Clover
		dragan = 'allowed',		-- Dragan
		jacket = 'allowed',		-- Jacket
		bonnie = 'allowed',		-- Bonnie
		sokol = 'allowed',		-- Sokol
		dragon = 'allowed',		-- Jiro
		bodhi = 'allowed',		-- Bodhi
		jimmy = 'allowed',		-- Jimmy
		sydney = 'allowed',		-- Sydney
		wild = 'allowed',		-- Rust
		chico = 'allowed',		-- Scarface
		max = 'allowed',		-- Sangres
		joy = 'allowed',		-- Joy
		myh = 'allowed',		-- Duke
		ecp_female = 'allowed',	-- Hila
		ecp_male = 'allowed'	-- Ethan
	},

	-- Here lies the escapes. Made obsolete by Overkill's addition of keeping the bots carry over between days. Thanks Overkill!
 
}

	---------------------
	--    Bot Blocking	--
	---------------------

function CriminalsManager:get_free_character_name()
	local available = {}
	for id, data in pairs(self._characters) do
		local taken = data.taken
		if not taken then
			table.insert(available, data.name)
		end
	end
	
	local level = Global.game_settings.level_id
	for _, character in pairs(self._characters) do
		local blocked = nil
		if level and blocked_characters_per_heist[level] then
			blocked = blocked_characters_per_heist[level][character.name]
		end
		if blocked_characters_per_heist.default then
			if not blocked then blocked = blocked_characters_per_heist.default[character.name] end
		end
		if blocked == 'blocked' and table.contains(available, character.name) then
			if table.size(available) > 1 then
				table.delete(available, character.name)
			else
				return
			end
		end
	end
	
	if #available > 0 then
		return available[math.random(#available)]
	end
end

function CriminalsManager:save_current_character_names()
	return
end

	---------------------
	--    Mask Changing	--
	---------------------

local change_mask_per_heist = {

    -- Armored Transport - All wearing Hockey Heat
    arm_cro = {all = 'heat'},
    arm_und = {all = 'heat'},
    arm_hcm = {all = 'heat'},
    arm_par = {all = 'heat'},
    arm_fac = {all = 'heat'},
	arm_for = {all = 'heat'},
	
    -- Hoxton will wear his old mask on Clasic Heists
    red2 = {
        old_hoxton = 'hoxton'
    },
	
	dinner = {
        old_hoxton = 'hoxton'
    },
	
	pal = {
        old_hoxton = 'hoxton'
    },
	
	man = {
        old_hoxton = 'hoxton'
    },
	
	flat = {
        old_hoxton = 'hoxton'
	},
	
	run = {
        old_hoxton = 'hoxton'
    },
	
	glace = {
        old_hoxton = 'hoxton'
    },
	
	dah = {
        old_hoxton = 'hoxton'
	},
	
	nmh = {
        old_hoxton = 'hoxton'
    },
	
	-- Zombie Masks on Prison Nightmare
    help = {
        russian = 'hwl_dallas_zombie',
		german = 'hwl_wolf_zombie',
		spanish = 'howl_chains_zombie',
		american = 'hwl_hoxton_zombie'
    }
}

function CriminalsManager:_change_ai_masks()
    local level = Global.game_settings.level_id
    for _, character in pairs(self._characters) do
        local new_mask = nil
        if level and change_mask_per_heist[level] then
            new_mask = change_mask_per_heist[level][character.name]
            if not new_mask then new_mask = change_mask_per_heist[level].all end
        end
        if change_mask_per_heist.default then
            if not new_mask then new_mask = change_mask_per_heist.default[character.name] end
            if not new_mask then new_mask = change_mask_per_heist.default.all end
        end
        if type(new_mask) == 'table' then new_mask = new_mask[math.random(#new_mask)] end
        if new_mask and new_mask ~= '' then
            character.static_data.ai_mask_id = new_mask
        end
    end
end

local create_characters_original = CriminalsManager._create_characters
function CriminalsManager:_create_characters(...)
    create_characters_original(self, ...)
    self:_change_ai_masks()
end

function CriminalsManager:add_character(name, unit, peer_id, ai, ai_loadout)
	print("[CriminalsManager]:add_character", name, unit, peer_id, ai)

	local character = self:character_by_name(name)

	if character then
		if character.taken then
			Application:error("[CriminalsManager:set_character] Error: Trying to take a unit slot that has already been taken!")
			Application:stack_dump()
			Application:error("[CriminalsManager:set_character] -----")
			self:remove_character_by_name(name)
		end

		character.taken = true
		character.unit = unit
		character.peer_id = peer_id
		character.data.ai = ai or false

		if ai_loadout then
			unit:base():set_loadout(ai_loadout)
		end

		character.data.mask_id = character.static_data.ai_mask_id

		-- if Network:is_server() and ai_loadout then
		-- 	local crafted = managers.blackmarket:get_crafted_category_slot("masks", ai_loadout and ai_loadout.mask_slot)
		-- 	character.data.mask_blueprint = crafted and crafted.blueprint
		-- end

		-- character.data.mask_blueprint = character.data.mask_blueprint
		character.data.mask_obj = managers.blackmarket:mask_unit_name_by_mask_id(character.data.mask_id, nil, name)

		if not ai and unit then
			local mask_id = managers.network:session():peer(peer_id):mask_id()
			character.data.mask_obj = managers.blackmarket:mask_unit_name_by_mask_id(mask_id, peer_id)
			character.data.mask_id = managers.blackmarket:get_real_mask_id(mask_id, peer_id)
			character.data.mask_blueprint = managers.network:session():peer(peer_id):mask_blueprint()
		end

		managers.hud:remove_mugshot_by_character_name(name)

		if unit then
			character.data.mugshot_id = managers.hud:add_mugshot_by_unit(unit)

			if unit:base().is_local_player then
				self._local_character = name

				managers.hud:reset_player_hpbar()
			end

			unit:sound():set_voice(character.static_data.voice)
		else
			character.data.mugshot_id = managers.hud:add_mugshot_without_unit(name, ai, peer_id, ai and managers.localization:text("menu_" .. name) or managers.network:session():peer(peer_id):name())
		end
	end

	self:event_listener():call("on_criminal_added", name, unit, peer_id, ai)
	managers.sync:send_all_synced_units_to(peer_id)
end