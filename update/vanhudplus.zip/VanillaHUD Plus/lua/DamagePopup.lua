
if RequiredScript == "lib/units/enemies/cop/copdamage" and not VHUDPlus.dmg_pop then
	VHUDPlus.dmg_pop = true
	local init_original = CopDamage.init
	function CopDamage.init(self, ...)
		self._head_body_name = self._head_body_name
		init_original(self, ...)
		self._hud = HoxPopUp:new(self._unit)
	end

	if not VHUDPlus:getSetting({"DamagePopup", "LINUXCOMPAT"}, true) then
		HoxPopUp = HoxPopUp or class()
	end

	local _update_debug_ws_original = CopDamage._update_debug_ws
		
	function CopDamage:_update_debug_ws(data, ...)
		self:popup_kill(data)
		-- self:_process_popup_damage(data)
		self._sync_ibody_popup = nil
		return _update_debug_ws_original(self, data, ...)
	end

	function CopDamage:popup_kill(data)
		if not VHUDPlus:getSetting({"DamagePopup", "LINUXCOMPAT"}, true) then return end

		local damage = tonumber(data.damage) or 0

		local attacker = alive(data.attacker_unit) and data.attacker_unit
		local killer

		if attacker and damage >= 0.1 then
			local body = data and data.col_ray and data.col_ray.body
			local headshot = body and self.is_head and self:is_head(body) or false
			if data and data.variant == "bullet" and attacker:in_slot(2) then
				killer = attacker
				self._hud:show_damage(damage, self._dead, headshot)
			elseif data and data.variant == "melee" and attacker:in_slot(2) then
				killer = attacker
				self._hud:show_damage(damage, self._dead, headshot)
			elseif data and data.variant == "explosion" and attacker:in_slot(2) then
				killer = attacker
				self._hud:show_damage(damage, self._dead, false)
			elseif data and data.variant == "fire" and attacker:in_slot(2) then
				killer = attacker
				self._hud:show_damage(damage, self._dead, false)
			elseif data and data.variant == "poison" and attacker:in_slot(2) then
				killer = attacker
				self._hud:show_damage(damage, self._dead, headshot)
			end
		end
	end

elseif RequiredScript == "lib/units/civilians/civiliandamage" then
	--Not Needed
end
