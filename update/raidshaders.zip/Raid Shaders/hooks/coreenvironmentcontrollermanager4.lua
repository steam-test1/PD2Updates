local flashbang_test_offset = Vector3(0, 0, 150)
local debug_vec1 = Vector3()
local temp_vec_1 = Vector3()

CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_START = 0.5
CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_END = 0.1
CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_POWER = 2
CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_INTERVAL = CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_START - CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_END
CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_PULSE_AMPLITUDE = 0.4
CoreEnvironmentControllerManager.LOW_HEALTH_EFFECT_PULSE_FREQ = 200
CoreEnvironmentControllerManager.DEFAULT_DOF_DISTANCE = 10

local init_original_test = CoreEnvironmentControllerManager.init

function CoreEnvironmentControllerManager:init()
	init_original_test(self)
	self._last_life_mod = 1
	self._vignette = 0
	self._lut_lerp_value = 0
	self._lens_distortion = self:get_default_lens_distortion_value()
end

function CoreEnvironmentControllerManager:get_default_lens_distortion_value()
	return 1.02
end

function CoreEnvironmentControllerManager:get_lens_distortion_value()
	return self._lens_distortion
end

function CoreEnvironmentControllerManager:reset_lens_distortion_value()
	self:set_lens_distortion_power(self:get_default_lens_distortion_value())
end

function CoreEnvironmentControllerManager:set_lens_distortion_power(lens_distortion)
	self._lens_distortion = lens_distortion
end

function CoreEnvironmentControllerManager:set_vignette(vignette)
	self._vignette = vignette
end

function CoreEnvironmentControllerManager:set_last_life_mod(last_life_mod)
	self._last_life_mod = last_life_mod
end

local ids_dof_near_plane = Idstring("near_plane")
local ids_dof_far_plane = Idstring("far_plane")
local ids_dof_settings = Idstring("settings")
local ids_radial_pos = Idstring("radial_pos")
local ids_radial_offset = Idstring("radial_offset")
local ids_tgl_r = Idstring("tgl_r")
local hit_feedback_rlu = Idstring("hit_feedback_rlu")
local hit_feedback_d = Idstring("hit_feedback_d")
local ids_dof_prepare_post_processor = Idstring("dof_prepare_post_processor")
local ids_hdr_post_processor = Idstring("hdr_post_processor")
local ids_hdr_post_composite = Idstring("post_DOF")
local mvec1 = Vector3()
local mvec2 = Vector3()
local new_cam_fwd = Vector3()
local new_cam_up = Vector3()
local new_cam_right = Vector3()
local ids_LUT_post = Idstring("color_grading_post")
local ids_LUT_settings = Idstring("lut_settings")
local ids_LUT_settings_a = Idstring("LUT_settings_a")
local ids_LUT_settings_b = Idstring("LUT_settings_b")
local ids_LUT_contrast = Idstring("contrast")
local ids_lens_distortion_post = Idstring("lens_distortion")
local ids_lens_distortion_settings = Idstring("lens_distortion_mod")
local ids_lens_distortion_power = Idstring("distortion_power")
local ids_ao_post_processor = Idstring("ao_post_processor")
local ids_ao_mask_post_processor = Idstring("ao_mask_post_processor")

function CoreEnvironmentControllerManager:set_lut_lerp_value(lut_lerp_value)
	self._lut_lerp_value = lut_lerp_value
end

Hooks:PostHook(CoreEnvironmentControllerManager, "set_post_composite", "add_lens_distortion", function(self, t, dt)
	local vp = managers.viewport:first_active_viewport()

	if not vp then
		return
	end

	local lens_distortion_post = vp:vp():get_post_processor_effect("World", ids_lens_distortion_post)

	if lens_distortion_post then
		local lens_distortion_modifier = lens_distortion_post:modifier(ids_lens_distortion_settings)

		if lens_distortion_modifier then
			local lens_distortion_modifier_material = lens_distortion_modifier:material()

			if lens_distortion_modifier_material then
				lens_distortion_modifier_material:set_variable(ids_lens_distortion_power, self._lens_distortion)
			end
		end
	end
end)

function CoreEnvironmentControllerManager:_update_post_effects()
	self:set_ao_setting(managers.user:get_setting("video_ao"))
	self:set_parallax_setting(managers.user:get_setting("parallax_mapping"))
	self:set_aa_setting(managers.user:get_setting("video_aa"))
	self:set_volumetric_light_scatter_setting("standard")
	self:set_motion_blur_setting("standard")
	self:set_ssao_setting("standard")
end

local function set_modifier_transform(effect, id, transform)
	local modifier = effect:modifier(Idstring(id))

	if modifier then
		transform(modifier)

		return
	end

	local count = 1

	while true do
		local id = Idstring(id .. "_" .. count)
		modifier = effect:modifier(id)

		if modifier then
			transform(modifier)
		else
			break
		end

		count = count + 1
	end
end

local function set_modifier_visibility(effect, id, visibility_state)
	set_modifier_transform(effect, id, function (mod)
		mod:set_visibility(visibility_state)
	end)
end

local function set_post_material_parameter(post_id, modifier_name, parameter_id, value)
	local vp = managers.viewport:first_active_viewport()

	if vp then
		local effect = vp:vp():get_post_processor_effect("World", post_id)

		if effect then
			set_modifier_transform(effect, modifier_name, function (modifier)
				local material = modifier:material()

				if material then
					material:set_variable(parameter_id, value)
				end
			end)
		end
	end
end

function CoreEnvironmentControllerManager:set_colorblind_mode(setting)
	local vp = managers.viewport:first_active_viewport()

	if vp then
		local cb_correction = vp:vp():get_post_processor_effect("World", Idstring("colorblind_correction_post"))

		cb_correction:set_visibility(setting ~= "off")
	end

	World:set_colorblind_mode(Idstring(setting))
end

function CoreEnvironmentControllerManager:set_ssao_setting(setting)
	local vp = managers.viewport:first_active_viewport()

	if vp then
		local SSAO_processor = vp:vp():get_post_processor_effect("World", Idstring("SSAO_post_processor"))
		local ssao_intensity = 0

		if SSAO_processor then
			local SSAO_combiner = SSAO_processor:modifier(Idstring("apply_SSAO"))
			ssao_intensity = SSAO_combiner:material():get_variable(Idstring("ssao_intensity"))
		end

		local visibility = setting == "standard" and ssao_intensity > 0.001

		if SSAO_processor then
			SSAO_processor:set_visibility(visibility)
		end

		local SSAO_mask = vp:vp():get_post_processor_effect("World", Idstring("SSAO_mask_post_processor"))

		if SSAO_mask then
			SSAO_mask:set_visibility(visibility)
		end

		local deferred_processor = vp:vp():get_post_processor_effect("World", Idstring("deferred"))

		if deferred_processor then
			local apply_ambient = deferred_processor:modifier(Idstring("apply_ambient"))

			if apply_ambient then
				apply_ambient:material():set_variable(Idstring("use_ssao"), visibility and 1 or 0)
			end
		end
	end
end

function CoreEnvironmentControllerManager:set_motion_blur_setting(setting)
	local vp = managers.viewport:first_active_viewport()

	if vp then
		local motion_blur_processor = vp:vp():get_post_processor_effect("World", Idstring("post_motion_blur"))

		if motion_blur_processor then
			motion_blur_processor:set_visibility(setting == "standard")
		end
	end
end

function CoreEnvironmentControllerManager:set_volumetric_light_scatter_setting(setting)
	local vp = managers.viewport:first_active_viewport()

	if vp then
		local vls_processor = vp:vp():get_post_processor_effect("World", Idstring("volumetric_light_scatter"))

		if vls_processor then
			local vls_combiner = vls_processor:modifier(Idstring("post_volumetric_light_scatter"))

			if vls_combiner then
				local exposure_value = vls_combiner:material():get_variable(Idstring("light_scatter_exposure"))
				local visibility = setting == "standard" and exposure_value > 0.001

				vls_processor:set_visibility(visibility)
			end
		end
	end
end