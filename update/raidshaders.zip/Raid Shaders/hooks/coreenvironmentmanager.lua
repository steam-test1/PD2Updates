core:module("CoreEnvironmentManager")
core:import("CoreClass")
core:import("CoreEnvironmentHandler")
core:import("CoreEnvironmentFeeder")

EnvironmentManager = EnvironmentManager or CoreClass.class()
local extension = "environment"
local ids_extension = Idstring(extension)

function EnvironmentManager:init()
	self._env_data_map = {}
	self._feeder_class_map = {}
	self._global_feeder_map = {}
	self._predefined_environment_filter_map = {}
	self._global_environment_modifier_map = {}
	self._game_default_environment_path = "core/environments/default"
	self._default_environment_path = self._game_default_environment_path
	local feeder_class_list = {
		CoreEnvironmentFeeder.UnderlayPathFeeder,
		CoreEnvironmentFeeder.GlobalLightColorFeeder,
		CoreEnvironmentFeeder.GlobalLightColorScaleFeeder,
		CoreEnvironmentFeeder.CubeMapTextureFeeder,
		CoreEnvironmentFeeder.WorldOverlayTextureFeeder,
		CoreEnvironmentFeeder.WorldOverlayMaskTextureFeeder,
		CoreEnvironmentFeeder.SkyRotationFeeder,
		CoreEnvironmentFeeder.UnderlaySkyTopColorFeeder,
		CoreEnvironmentFeeder.UnderlaySkyTopColorScaleFeeder,
		CoreEnvironmentFeeder.UnderlaySkyBottomColorFeeder,
		CoreEnvironmentFeeder.UnderlaySkyBottomColorScaleFeeder,
		CoreEnvironmentFeeder.PostSpecFactorFeeder,
		CoreEnvironmentFeeder.PostGlossFactorFeeder,
		CoreEnvironmentFeeder.PostAmbientFalloffScaleFeeder,
		CoreEnvironmentFeeder.PostAmbientColorFeeder,
		CoreEnvironmentFeeder.PostAmbientColorScaleFeeder,
		CoreEnvironmentFeeder.PostSkyTopColorFeeder,
		CoreEnvironmentFeeder.PostSkyTopColorFeeder,
		CoreEnvironmentFeeder.PostSkyTopColorScaleFeeder,
		CoreEnvironmentFeeder.PostSkyBottomColorFeeder,
		CoreEnvironmentFeeder.PostSkyBottomColorScaleFeeder,
		CoreEnvironmentFeeder.PostFogStartColorFeeder,
		CoreEnvironmentFeeder.PostFogFarLowColorFeeder,
		CoreEnvironmentFeeder.PostFogMinRangeFeeder,
		CoreEnvironmentFeeder.PostFogMaxRangeFeeder,
		CoreEnvironmentFeeder.PostFogMaxDensityFeeder,
		CoreEnvironmentFeeder.PostEffectLightScaleFeeder,
		CoreEnvironmentFeeder.SSAORadiusFeeder,
		CoreEnvironmentFeeder.SSAOIntensityFeeder,
		CoreEnvironmentFeeder.PostBloomIntensityFeeder,
		CoreEnvironmentFeeder.PostLFGhostDispersalFeeder,
		CoreEnvironmentFeeder.PostLFHaloWidthFeeder,
		CoreEnvironmentFeeder.PostLFChromaticDistortionFeeder,
		CoreEnvironmentFeeder.PostLFWeightExponentFeeder,
		CoreEnvironmentFeeder.PostLFDownsampleScaleFeeder,
		CoreEnvironmentFeeder.PostLFDownsampleBiasFeeder,
		CoreEnvironmentFeeder.PostVLSDensityFeeder,
		CoreEnvironmentFeeder.PostVLSWeightFeeder,
		CoreEnvironmentFeeder.PostVLSDecayFeeder,
		CoreEnvironmentFeeder.PostVLSExposureFeeder,
		CoreEnvironmentFeeder.PostShadowSlice0Feeder,
		CoreEnvironmentFeeder.PostShadowSlice1Feeder,
		CoreEnvironmentFeeder.PostShadowSlice2Feeder,
		CoreEnvironmentFeeder.PostShadowSlice3Feeder,
		CoreEnvironmentFeeder.PostShadowSliceDepthsFeeder,
		CoreEnvironmentFeeder.PostShadowSliceOverlapFeeder
	}

	for _, feeder_class in ipairs(feeder_class_list) do
		self._feeder_class_map[feeder_class.DATA_PATH_KEY] = feeder_class

		if feeder_class.FILTER_CATEGORY then
			local filter_list = self._predefined_environment_filter_map[feeder_class.FILTER_CATEGORY]

			if not filter_list then
				filter_list = {}
				self._predefined_environment_filter_map[feeder_class.FILTER_CATEGORY] = filter_list
			end

			table.insert(filter_list, feeder_class.DATA_PATH_KEY)
		end
	end

	self:preload_environment(self._game_default_environment_path)
end