table.insert(tweak_data.contour_styles, 
{
    value = "contour_pdth",
    text_id = "menu_contour_pdth"		
}
)

Hooks:Add("LocalizationManagerPostInit", "AddContourLocList", function(loc)
	LocalizationManager:add_localized_strings({
		["menu_contour_pdth"] = "PDTH"
    })	
end)