
if HUDManager then
    local _setup_player_info_hud_pd2_original = HUDManager._setup_player_info_hud_pd2
    function HUDManager:_setup_player_info_hud_pd2(...)
        _setup_player_info_hud_pd2_original(self,...)
        if not EffectsAlt then return end
            self._effects_alt = EffectsAlt:new(managers.gui_data:create_fullscreen_workspace():panel())
    end
    
    function HUDManager:activate_effects_alt(duration, color)
		self._effects_alt:run_effects_alt(duration, color)
    end
    
    function HUDManager:activate_effects_damage(duration)
		self._effects_alt:run_effects_damage(duration)
    end
    
    function HUDManager:activate_effects_low_health(duration)
		self._effects_alt:run_effects_low_health(duration)
	end
end

-- if GenericUserManager then
--     core:module("UserManager")
--     core:import("CoreEvent")
--     core:import("CoreTable")

--     local setup_setting_map_ori = GenericUserManager.setup_setting_map

--     function GenericUserManager:setup_setting_map()
--         self:setup_setting(48, "video_ao", "AO_off")

--         return setup_setting_map_ori(self)
--     end
-- end

if PlayerDamage then
    function PlayerDamage:_damage_screen()
        local armor_ratio = self:armor_ratio()
        self._hurt_value = 1 - math.clamp(0.8 - math.pow(armor_ratio, 2), 0, 1)
        self._armor_value = math.clamp(armor_ratio, 0, 1)
    
        managers.hud:activate_effects_damage(self._hurt_value)
        managers.environment_controller:set_hurt_value(self._hurt_value)
        self._listener_holder:call("on_damage")
    end

    -- local update_ori = PlayerDamage.update
    -- function PlayerDamage:update(unit, t, dt)
    --     update_ori(self, unit, t, dt)
    --     if not self._downed_timer and self._downed_progression then
    --         self._downed_progression = math.max(0, self._downed_progression - dt * 50)
    
    --         if not _G.IS_VR then
    --             managers.hud:activate_effects_low_health(0.75)
    --             managers.environment_controller:set_downed_value(self._downed_progression)
    --         end
    
    --         SoundDevice:set_rtpc("downed_state_progression", self._downed_progression)
    
    --         if self._downed_progression == 0 then
    --             self._unit:sound():play("critical_state_heart_stop")
    
    --             self._downed_progression = nil
    --         end
    --     end
    -- end

    local stop_heartbeat_ori = PlayerDamage.stop_heartbeat
    function PlayerDamage:stop_heartbeat()
        stop_heartbeat_ori(self)
        managers.hud:activate_effects_low_health(0)
    end

    -- local update_downed_ori = PlayerDamage.update_downed
    -- function PlayerDamage:update_downed(t, dt)
    --     update_downed_ori(self, t, dt)
    --     if self._downed_timer and self._downed_paused_counter == 0 then
            
    --         if not _G.IS_VR then
    --             managers.hud:activate_effects_low_health(0.75)
    --             managers.environment_controller:set_downed_value(self._downed_progression)
    --         end
    --     end
    
    --     return false
    -- end

    local _check_bleed_out_ori = PlayerDamage._check_bleed_out
    function PlayerDamage:_check_bleed_out(can_activate_berserker, ignore_movement_state)
        _check_bleed_out_ori(self, can_activate_berserker, ignore_movement_state)
        if self:get_real_health() == 0 and not self._check_berserker_done then
            managers.hud:activate_effects_low_health(0)
            managers.environment_controller:set_downed_value(0)
        end
    end

    local pre_destroy_ori = PlayerDamage.pre_destroy
    function PlayerDamage:pre_destroy()
        pre_destroy_ori(self)
        managers.hud:activate_effects_damage(1)
        managers.hud:activate_effects_low_health(0)
    end
end

EffectsAlt = EffectsAlt or class()

function EffectsAlt:init(hud)
	self._full_hud = hud
	
	self._effect_panel = self._full_hud:panel({
		name = "effect_panel",
		visible = true
	})

	self._effect_panel = self._full_hud:bitmap({
		name = "effect_panel1",
		visible = true,
		texture = "guis/effects/flashbang",
		layer = 0,
		color = Color(1, 1, 1),
		alpha = 0,
        blend_mode = "add",
        -- render_template = "VertexColorTexturedBlur3D",
		w = self._full_hud:w(),
		h = self._full_hud:h(),
		x = 0,
		y = 0 
    })

    self._heavy_damage_panel = self._full_hud:panel({
		name = "heavy_damage_panel",
		visible = true
    })
    
    self._heavy_damage_panel = self._full_hud:bitmap({
		name = "heavy_damage_panel1",
		visible = true,
		texture = "guis/effects/damage_heavy",
		layer = 0,
		color = Color(1, 1, 1),
		alpha = 0,
        blend_mode = "add",
        -- render_template = "VertexColorTexturedBlur3D",
		w = self._full_hud:w(),
		h = self._full_hud:h(),
		x = 0,
		y = 0 
    })

    self._low_health_panel = self._full_hud:panel({
		name = "low_health_panel",
		visible = true
    })
    
    self._low_health_panel = self._full_hud:bitmap({
		name = "low_health_panel1",
		visible = true,
		texture = "guis/effects/low_health",
		layer = 0,
		color = Color(1, 1, 1),
		alpha = 0,
        blend_mode = "add",
        -- render_template = "VertexColorTexturedBlur3D",
		w = self._full_hud:w(),
		h = self._full_hud:h(),
		x = 0,
		y = 0 
    })
    
    -- self._blur_panel = self._full_hud:panel({
	-- 	name = "effect_blur_panel",
	-- 	visible = true
	-- })

	self._active = 0.0
    self._duration = 0.0
    self._alpha = 0.0
end

function EffectsAlt:run_effects_alt(duration)
    self._effect_panel:set_alpha(1)
    -- self._blur_panel:set_alpha(1)
    self._duration = duration
    if self._active == true then
        self._effect_panel:stop()
    end
    self._active = true
    self._effect_panel:animate(callback(self, self, "_fadeout_effects_alt"))
    -- local blur = self._blur_panel:bitmap({
	-- 	texture = "guis/textures/test_blur_df",
	-- 	render_template = "VertexColorTexturedBlur3D",
	-- 	w = self._full_hud:w(),
	-- 	h = self._full_hud:h(),
	-- 	layer = 1
    -- })
    -- local function func(o)
	-- 	local start_blur = 0

	-- 	over(0.6, function (p)
	-- 		o:set_alpha(math.lerp(start_blur, 1, p))
	-- 	end)
	-- end

	-- blur:animate(func)
end

function EffectsAlt:_fadeout_effects_alt()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._duration do
		curr_time = Application:time()
        self._effect_panel:set_alpha(1 * self._duration)
        -- self._blur_panel:set_alpha(1 * self._duration)
		coroutine.yield()
    end
    
    self._effect_panel:set_alpha(0)
    -- self._blur_panel:set_alpha(0)
	self._active = false
end

function EffectsAlt:run_effects_damage(duration)
    self._heavy_damage_panel:set_alpha(1)
    -- self._blur_panel:set_alpha(1)
    self._duration = duration
    if self._active == true then
        self._heavy_damage_panel:stop()
    end
    self._active = true
    self._heavy_damage_panel:animate(callback(self, self, "_fadeout_effects_damage"))
    -- local blur = self._blur_panel:bitmap({
	-- 	texture = "guis/textures/test_blur_df",
	-- 	render_template = "VertexColorTexturedBlur3D",
	-- 	w = self._full_hud:w(),
	-- 	h = self._full_hud:h(),
	-- 	layer = 1
    -- })
    -- local function func(o)
	-- 	local start_blur = 0

	-- 	over(0.6, function (p)
	-- 		o:set_alpha(math.lerp(start_blur, 1, p))
	-- 	end)
	-- end

	-- blur:animate(func)
end

function EffectsAlt:_fadeout_effects_damage()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._duration do
		curr_time = Application:time()
        self._heavy_damage_panel:set_alpha(PDTHContours.Options:GetValue("RedAlpha") * self._duration)
        self._heavy_damage_panel:set_color(Color(255, 0, 0))
        -- self._blur_panel:set_alpha(1 * self._duration)
		coroutine.yield()
    end
    
    self._heavy_damage_panel:set_alpha(0)
    -- self._blur_panel:set_alpha(0)
	self._active = false
end

function EffectsAlt:run_effects_low_health(duration)
    self._low_health_panel:set_alpha(1)
    -- self._blur_panel:set_alpha(1)
    self._duration = duration
    self._alpha = alpha
    if self._active == true then
        self._low_health_panel:stop()
    end
    self._active = true
    self._low_health_panel:animate(callback(self, self, "_fadeout_effects_low_health"))
    -- local blur = self._blur_panel:bitmap({
	-- 	texture = "guis/textures/test_blur_df",
	-- 	render_template = "VertexColorTexturedBlur3D",
	-- 	w = self._full_hud:w(),
	-- 	h = self._full_hud:h(),
	-- 	layer = 1
    -- })
    -- local function func(o)
	-- 	local start_blur = 0

	-- 	over(0.6, function (p)
	-- 		o:set_alpha(math.lerp(start_blur, 1, p))
	-- 	end)
	-- end

	-- blur:animate(func)
end

function EffectsAlt:_fadeout_effects_low_health()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._duration do
		curr_time = Application:time()
        self._low_health_panel:set_alpha(1 * self._duration)
        self._low_health_panel:set_color(Color(255, 0, 0))
        -- self._blur_panel:set_alpha(1 * self._duration)
		coroutine.yield()
    end
    
    self._low_health_panel:set_alpha(0)
    -- self._blur_panel:set_alpha(0)
	self._active = false
end