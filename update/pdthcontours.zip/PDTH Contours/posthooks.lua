
if HUDManager then
    local _setup_player_info_hud_pd2_original = HUDManager._setup_player_info_hud_pd2
    function HUDManager:_setup_player_info_hud_pd2(...)
        _setup_player_info_hud_pd2_original(self,...)
        if not EffectsAlt then return end
            self._effects_alt = EffectsAlt:new(managers.gui_data:create_fullscreen_workspace():panel())
    end
    
    function HUDManager:activate_effects_alt(duration, color)
		self._effects_alt:run_effects_alt(duration, color)
    end
    
    function HUDManager:activate_effects_damage(duration)
		self._effects_alt:run_effects_damage(duration)
    end
    
    function HUDManager:activate_effects_low_health(duration)
		self._effects_alt:run_effects_low_health(duration)
	end
end

-- if GenericUserManager then
--     core:module("UserManager")
--     core:import("CoreEvent")
--     core:import("CoreTable")

--     local setup_setting_map_ori = GenericUserManager.setup_setting_map

--     function GenericUserManager:setup_setting_map()
--         self:setup_setting(48, "video_ao", "AO_off")

--         return setup_setting_map_ori(self)
--     end
-- end

if PlayerDamage then
    function PlayerDamage:_damage_screen()
        local armor_ratio = self:armor_ratio()
        self._hurt_value = 1 - math.clamp(0.8 - math.pow(armor_ratio, 2), 0, 1)
        self._armor_value = math.clamp(armor_ratio, 0, 1)
    
        managers.hud:activate_effects_damage(self._hurt_value)
        managers.environment_controller:set_hurt_value(self._hurt_value)
        self._listener_holder:call("on_damage")
    end

    Hooks:PreHook(PlayerDamage, "damage_fire", "damage_fire_pdth", function(self, attack_data)
        self:_damage_screen()
        -- managers.hud:activate_effects_damage(1)
    end)

    -- Hooks:PreHook(PlayerDamage, "damage_explosion", "damage_explosion_pdth", function(self, attack_data)
    --     managers.hud:activate_effects_damage(0.8)
    -- end)

    Hooks:PreHook(PlayerDamage, "on_downed", "on_downed_pdth", function(self, data)
        -- if not self._mission_damage_blockers.damage_fall_disabled and self:incapacitated() then
            managers.hud:activate_effects_low_health(2.4)
        -- end
    end)
end

EffectsAlt = EffectsAlt or class()

function EffectsAlt:init(hud)
	self._full_hud = hud
	
	self._flashbang_panel = self._full_hud:panel({
		name = "effect_panel",
		visible = true
    })
    
    -- local flashbang_texture
    -- if PDTHContours.Options:GetValue("FlashbangColor") == 1 then
    --     flashbang_texture = "guis/effects/flashbang"
    -- elseif PDTHContours.Options:GetValue("FlashbangColor") == 2 then
    --     flashbang_texture = "guis/effects/inverted_flashbang"
    -- end
     
	self._flashbang_panel = self._full_hud:bitmap({
		name = "effect_panel1",
		visible = true,
		texture = "guis/effects/flashbang",
		layer = 0,
		color = Color(1, 1, 1),
		alpha = 0,
        blend_mode = "add",
        -- render_template = "VertexColorTexturedBlur3D",
		w = self._full_hud:w(),
		h = self._full_hud:h(),
		x = 0,
		y = 0 
    })

    self._heavy_damage_panel = self._full_hud:panel({
		name = "heavy_damage_panel",
		visible = true
    })
    
    self._heavy_damage_panel = self._full_hud:bitmap({
		name = "heavy_damage_panel1",
		visible = true,
		texture = "guis/effects/damage_heavy",
		layer = 0,
		color = Color(1, 1, 1),
		alpha = 0,
        blend_mode = "add",
        -- render_template = "VertexColorTexturedBlur3D",
		w = self._full_hud:w(),
		h = self._full_hud:h(),
		x = 0,
		y = 0 
    })

    self._low_health_panel = self._full_hud:panel({
		name = "low_health_panel",
		visible = true
    })
    
    self._low_health_panel = self._full_hud:bitmap({
		name = "low_health_panel1",
		visible = true,
		texture = "guis/effects/low_health",
		layer = 0,
		color = Color(1, 1, 1),
		alpha = 0,
        blend_mode = "add",
        -- render_template = "VertexColorTexturedBlur3D",
		w = self._full_hud:w(),
		h = self._full_hud:h(),
		x = 0,
		y = 0 
    })
    
    -- self._blur_panel = self._full_hud:panel({
	-- 	name = "effect_blur_panel",
	-- 	visible = true
	-- })

	self._active = 0.0
    self._duration = 0.0
    self._alpha = 0.0
end

function EffectsAlt:run_effects_alt(duration)
    self._flashbang_panel:set_alpha(1)
    -- self._blur_panel:set_alpha(1)
    self._duration = duration
    if self._active == true then
        self._flashbang_panel:stop()
    end
    self._active = true
    self._flashbang_panel:animate(callback(self, self, "_fadeout_effects_alt"))
    -- local blur = self._blur_panel:bitmap({
	-- 	texture = "guis/textures/test_blur_df",
	-- 	render_template = "VertexColorTexturedBlur3D",
	-- 	w = self._full_hud:w(),
	-- 	h = self._full_hud:h(),
	-- 	layer = 1
    -- })
    -- local function func(o)
	-- 	local start_blur = 0

	-- 	over(0.6, function (p)
	-- 		o:set_alpha(math.lerp(start_blur, 1, p))
	-- 	end)
	-- end

	-- blur:animate(func)
end

function EffectsAlt:_fadeout_effects_alt()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._duration do
		curr_time = Application:time()
        self._flashbang_panel:set_alpha(1 * self._duration)
        -- self._blur_panel:set_alpha(1 * self._duration)
		coroutine.yield()
    end
    
    self._flashbang_panel:set_alpha(0)
    -- self._blur_panel:set_alpha(0)
	self._active = false
end

function EffectsAlt:run_effects_damage(duration)
    self._heavy_damage_panel:set_alpha(1)
    -- self._blur_panel:set_alpha(1)
    self._duration = duration
    if self._active == true then
        self._heavy_damage_panel:stop()
    end
    self._active = true
    self._heavy_damage_panel:animate(callback(self, self, "_fadeout_effects_damage"))
    -- local blur = self._blur_panel:bitmap({
	-- 	texture = "guis/textures/test_blur_df",
	-- 	render_template = "VertexColorTexturedBlur3D",
	-- 	w = self._full_hud:w(),
	-- 	h = self._full_hud:h(),
	-- 	layer = 1
    -- })
    -- local function func(o)
	-- 	local start_blur = 0

	-- 	over(0.6, function (p)
	-- 		o:set_alpha(math.lerp(start_blur, 1, p))
	-- 	end)
	-- end

	-- blur:animate(func)
end

function EffectsAlt:_fadeout_effects_damage()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._duration do
		curr_time = Application:time()
        self._heavy_damage_panel:set_alpha(PDTHContours.Options:GetValue("RedAlpha") * self._duration)
        self._heavy_damage_panel:set_color(Color(255, 0, 0))
        -- self._blur_panel:set_alpha(1 * self._duration)
		coroutine.yield()
    end
    
    self._heavy_damage_panel:set_alpha(0)
    -- self._blur_panel:set_alpha(0)
	self._active = false
end

function EffectsAlt:run_effects_low_health(duration)
    self._low_health_panel:set_alpha(1)
    -- self._blur_panel:set_alpha(1)
    self._duration = duration
    self._alpha = alpha
    if self._active == true then
        self._low_health_panel:stop()
    end
    self._active = true
    self._low_health_panel:animate(callback(self, self, "_fadeout_effects_low_health"))
    -- local blur = self._blur_panel:bitmap({
	-- 	texture = "guis/textures/test_blur_df",
	-- 	render_template = "VertexColorTexturedBlur3D",
	-- 	w = self._full_hud:w(),
	-- 	h = self._full_hud:h(),
	-- 	layer = 1
    -- })
    -- local function func(o)
	-- 	local start_blur = 0

	-- 	over(0.6, function (p)
	-- 		o:set_alpha(math.lerp(start_blur, 1, p))
	-- 	end)
	-- end

	-- blur:animate(func)
end

function EffectsAlt:_fadeout_effects_low_health()
	local start_time = Application:time()
	local curr_time = start_time
	while curr_time - start_time < self._duration do
		curr_time = Application:time()
        self._low_health_panel:set_alpha(PDTHContours.Options:GetValue("RedAlpha") * self._duration)
        self._low_health_panel:set_color(Color(255, 0, 0))
        -- self._blur_panel:set_alpha(1 * self._duration)
		coroutine.yield()
    end
    
    self._low_health_panel:set_alpha(0)
    -- self._blur_panel:set_alpha(0)
	self._active = false
end