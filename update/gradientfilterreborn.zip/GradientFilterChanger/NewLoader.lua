gradselreborn = gradselreborn or 
{
	 mod_path 	= ModPath
	,save_path 	= SavePath .. "gradselrebornNew.lua"
	,gradsel_main_menu 	= "gradsel_main_menu"
	,random_table_menu1 = "random_table_menu1"
	,options 	= { random_table = {} }
	,levels		= {}
	,levels_data= {}
	,GDScontracts	= { ["unknow"] = 0 }
	,override_all_value = {}
    ,override_all = {}
	,exclude_form_random = {}
}

--[[
	https://github.com/hipe/lua-table-persistence
	Copyright (c) 2010 Gerhard Roethlin
]]
local write, writeIndent, writers, refCount;

persistence =
{
	store = function (path, ...)
		local file, e = io.open(path, "w");
		if not file then
			return error(e);
		end
		local n = select("#", ...);
		-- Count references
		local objRefCount = {}; -- Stores reference that will be exported
		for i = 1, n do
			refCount(objRefCount, (select(i,...)));
		end;
		-- Export Objects with more than one ref and assign name
		-- First, create empty tables for each
		local objRefNames = {};
		local objRefIdx = 0;
		file:write("-- Persistent Data\n");
		file:write("local multiRefObjects = {\n");
		for obj, count in pairs(objRefCount) do
			if count > 1 then
				objRefIdx = objRefIdx + 1;
				objRefNames[obj] = objRefIdx;
				file:write("{};"); -- table objRefIdx
			end;
		end;
		file:write("\n} -- multiRefObjects\n");
		-- Then fill them (this requires all empty multiRefObjects to exist)
		for obj, idx in pairs(objRefNames) do
			for k, v in pairs(obj) do
				file:write("multiRefObjects["..idx.."][");
				write(file, k, 0, objRefNames);
				file:write("] = ");
				write(file, v, 0, objRefNames);
				file:write(";\n");
			end;
		end;
		-- Create the remaining objects
		for i = 1, n do
			file:write("local ".."obj"..i.." = ");
			write(file, (select(i,...)), 0, objRefNames);
			file:write("\n");
		end
		-- Return them
		if n > 0 then
			file:write("return obj1");
			for i = 2, n do
				file:write(" ,obj"..i);
			end;
			file:write("\n");
		else
			file:write("return\n");
		end;
		if type(path) == "string" then
			file:close();
		end;
	end;

	load = function (path)
		local f, e;
		if type(path) == "string" then
			f, e = blt.vm.loadfile(path);
		else
			f, e = path:read('*a')
		end
		if f then
			return f();
		else
			return nil, e;
		end;
	end;
}

-- Private methods

-- write thing (dispatcher)
write = function (file, item, level, objRefNames)
	writers[type(item)](file, item, level, objRefNames);
end;

-- write indent
writeIndent = function (file, level)
	for i = 1, level do
		file:write("\t");
	end;
end;

-- recursively count references
refCount = function (objRefCount, item)
	-- only count reference types (tables)
	if type(item) == "table" then
		-- Increase ref count
		if objRefCount[item] then
			objRefCount[item] = objRefCount[item] + 1;
		else
			objRefCount[item] = 1;
			-- If first encounter, traverse
			for k, v in pairs(item) do
				refCount(objRefCount, k);
				refCount(objRefCount, v);
			end;
		end;
	end;
end;

-- Format items for the purpose of restoring
writers = {
	["nil"] = function (file, item)
			file:write("nil");
		end;
	["number"] = function (file, item)
			file:write(tostring(item));
		end;
	["string"] = function (file, item)
			file:write(string.format("%q", item));
		end;
	["boolean"] = function (file, item)
			if item then
				file:write("true");
			else
				file:write("false");
			end
		end;
	["table"] = function (file, item, level, objRefNames)
			local refIdx = objRefNames[item];
			if refIdx then
				-- Table with multiple references
				file:write("multiRefObjects["..refIdx.."]");
			else
				-- Single use table
				file:write("{\n");
				for k, v in pairs(item) do
					writeIndent(file, level+1);
					file:write("[");
					write(file, k, level+1, objRefNames);
					file:write("] = ");
					write(file, v, level+1, objRefNames);
					file:write(";\n");
				end
				writeIndent(file, level);
				file:write("}");
			end;
		end;
	["function"] = function (file, item)
			-- Does only work for "normal" functions, not those
			-- with upvalues or c functions
			local dInfo = debug.getinfo(item, "uS");
			if dInfo.nups > 0 then
				file:write("nil --[[functions with upvalue not supported]]");
			elseif dInfo.what ~= "Lua" then
				file:write("nil --[[non-lua function not supported]]");
			else
				local r, s = pcall(string.dump,item);
				if r then
					file:write(string.format("loadstring(%q)", s));
				else
					file:write("nil --[[function could not be dumped]]");
				end
			end
		end;
	["thread"] = function (file, item)
			file:write("nil --[[thread]]\n");
		end;
	["userdata"] = function (file, item)
			file:write("nil --[[userdata]]\n");
		end;
}

function gradselreborn:Load()
	local settings = persistence.load(self.save_path);
	if not settings then return end
	self.options = settings
	return settings
end

function gradselreborn:Save()
	persistence.store(self.save_path, self.options);
end
gradselreborn:Load()

function gradselreborn:LevelsByVal(fValue, tValue)
	if fValue == "all" then return self.levels end
	local levels = {}
	for k , v in pairs( self.levels_data or {} ) do
		if 		self.levels_data[k][fValue] == tValue 
		then	levels[v.level_id] = self.levels[v.level_id] end
	end
	if levels == {} then return nil end
	return levels
	--log(tostring(levels == {} and nil or levels))
	--return levels == {} and nil or levels
end

function gradselreborn:SetOptions(target, num, by)
	--if num == 1 then num = nil end
	local levels = target or {}
	if by == "contract" then levels = self:LevelsByVal("contact", target) 	end
	if by == "all"		then levels = self:LevelsByVal("all")				end
	
	for level_id, v in pairs( levels or {} ) do 
		self.options[level_id] = num
	end
	self:Save(gradselreborn.options)
	
	return levels
end

--------------------------------------------------------------------------------------------------------------

function GDSGetTableValue(table,value)
	if table ~= nil then return table[value] end
	return nil
end

function GDSParseJob(data)
	for i , v in pairs( data.tables or {} ) do
		if v.level_id ~= nil then --log("level_id " ..tostring(v.level_id))
			--log("/ " .. v.level_id )
			gradselreborn.levels_data[ v.level_id ] = gradselreborn.levels_data[ v.level_id ] or 
			{
				 level_id 		= v.level_id
				,job_id 		= data.job_id
				,job_name_id	= GDSGetTableValue(tweak_data.narrative.jobs[ data.job_id ], "name_id")
				,stage			= i + ( ( data.i and data.i - 1 ) or 0 )
				,contact		= GDSGetTableValue(tweak_data.narrative.jobs[ data.job_id ], "contact") or "unknow"
			}
		elseif type(v) == "table" and v.level_id == nil then 
			GDSParseJob({ tables = v or {} , job_id = data.job_id , i = i })
		end
	end
end

function create_env_table()
    for k, v in pairs(gradselreborn.gradsel_environments_table) do
        gradselreborn.override_all_value[k] = v.text_id
		gradselreborn.override_all[k] = v.value
    end
    return gradselreborn.override_all_value, gradselreborn.override_all
end

function gradselSet()
	local 	CustomLoaded = 0

	local normal

	for k in pairs (gradselreborn.options.random_table) do
        table.insert(gradselreborn.exclude_form_random, k)
    end

	normal = gradselreborn.exclude_form_random[ math.random( #gradselreborn.exclude_form_random ) ]
	
	for i , level_id in pairs( tweak_data.levels._level_index ) do
		-- Override Set
		if		tweak_data.levels[ level_id ] 
		and		gradselreborn.options[ "override" ] ~= nil
		and 	gradselreborn.options[ "override" ] >  1 then	
			if 	gradselreborn.options[ "override" ] == 2 then
				tweak_data.levels[ level_id ].env_params = { color_grading = normal }
				-- log(normal)
			else	tweak_data.levels[ level_id ].env_params = { color_grading = gradselreborn.override_all[ gradselreborn.options[ "override" ] or 1 ] } end
		--end
		-- set per map
		elseif	tweak_data.levels[ level_id ] 
		and		gradselreborn.options[ level_id ] ~= nil
		and 	gradselreborn.options[ level_id ] ~= 1 then
			if 	gradselreborn.options[ level_id ] == 2 then
				tweak_data.levels[ level_id ].env_params = { color_grading = normal }
			else	tweak_data.levels[ level_id ].env_params = { color_grading = gradselreborn.override_all[ gradselreborn.options[ level_id ] ] } end
					CustomLoaded = CustomLoaded + 1
			--log( "Custom Time Loaded: " .. level_id )
		end
	end
	if CustomLoaded > 0 then log( "/Custom Time Loaded: " .. tostring( CustomLoaded ) ) end
end
function gradselInstant()
	if not managers.worlddefinition then
		return
	end
	local 	CustomLoaded = 0

	local normal

	for k in pairs (gradselreborn.options.random_table) do
        table.insert(gradselreborn.exclude_form_random, k)
    end

	normal = gradselreborn.exclude_form_random[ math.random( #gradselreborn.exclude_form_random ) ]  

	local heist_name = managers.job:current_level_id()
	
	for i , level_id in pairs( tweak_data.levels._level_index ) do
		-- Override Set
		if		tweak_data.levels[ level_id ] 
		and		gradselreborn.options[ "override" ] ~= nil
		and 	gradselreborn.options[ "override" ] >  1 then	
			if 	gradselreborn.options[ "override" ] == 2 then
				tweak_data.levels[ level_id ].env_params = { color_grading = normal }
				-- log(normal)
			elseif gradselreborn.options[ "override" ] > 2 then
				managers.worlddefinition:_set_default_color_grading(gradselreborn.override_all[ gradselreborn.options[ "override" ] or 1 ] ) end
		--end
		-- set per map
		elseif	tweak_data.levels[ level_id ] 
		and		gradselreborn.options[ level_id ] ~= nil
		and 	gradselreborn.options[ level_id ] ~= 1 then
			if 	gradselreborn.options[ level_id ] == 2 then
				tweak_data.levels[ level_id ].env_params = { color_grading = normal }
			elseif gradselreborn.options[ level_id ] > 2 then
                managers.worlddefinition:_set_default_color_grading(gradselreborn.override_all[ gradselreborn.options[ level_id ] ] ) end
					CustomLoaded = CustomLoaded + 1
			--log( "Custom Time Loaded: " .. level_id )
		end
	end
	if CustomLoaded > 0 then log( "/Custom Time Loaded: " .. tostring( CustomLoaded ) ) end
end
--[[
function PrintTableNameList(table)
	for k , v in pairs(table) do
		log("/ " .. tostring(k) .. " /// " .. tostring(v) )
	end
end
--]]
--------------------------------------------------------------------------------------------------------------
function create_new_color_grading_table()
    tweak_data.color_grading[1] = {
        text_id = "menu_color_off"
    }
    tweak_data.color_grading[2] = {
		text_id = "menu_color_default"
	}
    tweak_data.color_grading[3] = {
        value = "color_heat",
        text_id = "menu_color_heat"
    }
    tweak_data.color_grading[4] = {
        value = "color_nice",
        text_id = "menu_color_nice"
    }
	tweak_data.color_grading[5] = {
        value = "color_bhd",
        text_id = "menu_color_bhd"
    }
    tweak_data.color_grading[6] = {
        value = "color_xgen",
        text_id = "menu_color_xgen"
    }
    tweak_data.color_grading[7] = {
        value = "color_xxxgen",
		text_id = "menu_color_xxxgen"
    }
    tweak_data.color_grading[8] = {
        value = "color_matrix_classic",
		text_id = "menu_color_matrix_classic"
    }
    tweak_data.color_grading[9] = {
        value = "color_sin_classic",
		text_id = "menu_color_sin_classic"
    }
    tweak_data.color_grading[10] = {
        value = "color_sepia",
		text_id = "menu_color_sepia"
    }
    tweak_data.color_grading[11] = {
        value = "color_sunsetstrip",
		text_id = "menu_color_sunsetstrip"
    }
    tweak_data.color_grading[12] = {
        value = "color_colorful",
		text_id = "menu_color_colorful"
    }
	tweak_data.color_grading[13] = {
        value = "color_madplanet",
		text_id = "menu_color_madplanet"
    }
    tweak_data.color_grading[14] = {
        value = "color_payday",
        text_id = "menu_color_payday"
    }
    tweak_data.color_grading[15] = {
        value = "color_matrix",
        text_id = "menu_color_matrix"
    }
	tweak_data.color_grading[16] = {
        value = "color_sin",
        text_id = "menu_color_sin"
    }
end

function create_color_grading_table()
    create_new_color_grading_table()
    for k, v in pairs(tweak_data.color_grading) do
        gradselreborn.override_all_value[k] = v.text_id
		gradselreborn.override_all[k] = v.value
    end
    return gradselreborn.override_all_value, gradselreborn.override_all
end
-------------------------------------------------------------------------------------------------------------------
local override_environments = {
    "standard"
}

if MenuSceneManager then
    Hooks:PostHook(MenuSceneManager, "_set_up_environments", "GradientFilterApplyMenuCGrade", function(self)
        for i, data in pairs(override_environments) do
            self._environments[data].color_grading = gradselreborn.options.menu_color_grading
        end
    end)
end

Hooks:Add("MenuManagerOnOpenMenu", "MenuManagerOnOpenMenu_ColourGrading", function( menu_manager, menu, position )
	UpdateColourGrading()
end)

function UpdateColourGrading()
	if not Utils:IsInGameState() then
		local grading = gradselreborn.override_all[ gradselreborn.options.menu_color_grading ]
		if grading then
			if managers.menu_scene then
				managers.menu_scene._environments.standard.color_grading = grading
			end
			if managers.environment_controller then
				managers.environment_controller:set_default_color_grading( grading )
				managers.environment_controller:refresh_render_settings()
			end
			
		end
	end
end

Hooks:Add("MenuManagerInitialize", "gradselmmi", function(menu_manager)
	MenuCallbackHandler.GDS_Close_Options 	= function(self)
		gradselSet()
		gradselInstant()
        managers.environment_controller:refresh_render_settings()
	end
	MenuCallbackHandler.GDS_Config_Reset 	= function(self, item) 	
		local type = item:name():sub(string.len("gradselID_Reset_") + 1)
		
		local levels = {}
		if   type == "all" 
		then levels = gradselreborn:SetOptions({}	 , 1, "all")
		else levels = gradselreborn:SetOptions(type, 1, "contract") end
		
		levels["override"] = ""
		
		if type == "all" then
			for k , v in pairs( gradselreborn.GDScontracts or {} ) do 
				local menu = MenuHelper:GetMenu( gradselreborn.gradsel_main_menu .. "_" .. k )
				ResetItems(menu, levels, 1)
			end
		end
		
		local menu_id = type == "all" and gradselreborn.gradsel_main_menu or gradselreborn.gradsel_main_menu .. "_" .. type
		local menu = MenuHelper:GetMenu( menu_id )
		
		ResetItems(menu, levels, 1)

		local items_to_reset = {
			["gradselID_menu_cg"] = true,
		}
		local default_value = 15
		MenuHelper:ResetItemsToDefaultValue( item, items_to_reset, default_value )
	end
	
	function ResetItems(menu, items, value)
		for k , v in pairs( items or {} ) do 
			local item = menu:item("gradselID_" .. k)
			if   item 
			then item._current_index = value or 1
				 item:dirty()
			end--item:set_enabled(false)
		end
	end
	
	MenuCallbackHandler.GFCReborn_ValueSet_Menu 		= function(self, item)
		if not Utils:IsInGameState() then
			gradselreborn.options.menu_color_grading = item:value()
			UpdateColourGrading()
			gradselreborn:Save()
		end
	end
	
	MenuCallbackHandler.GFCReborn_ValueSet 		= function(self, item)
		gradselreborn.options[ item:name():sub(11) ] = item:value()
		gradselreborn:Save()
        managers.environment_controller:refresh_render_settings()
	end

	gradselreborn:Load()

end)

Hooks:Add("MenuManagerSetupCustomMenus", "gradselreborn_sub", function( menu_manager, nodes )
	MenuHelper:NewMenu( gradselreborn.gradsel_main_menu )
	MenuHelper:NewMenu( gradselreborn.gradsel_main_menu .. "_unknow" )
    MenuHelper:NewMenu( gradselreborn.random_table_menu1 )

	gradselreborn.compatibility_with_daynight = deep_clone(tweak_data.narrative.contacts)
	
	for k , v in pairs( gradselreborn.compatibility_with_daynight ) do 
		gradselreborn.GDScontracts[k] = 0
		MenuHelper.menus = MenuHelper.menus or {}

		-- local gradsel_new_menu = deep_clone( MenuHelper.menu_to_clone )
		local gradsel_new_menu = deep_clone( MenuHelper.menus[gradselreborn.gradsel_main_menu] )
		gradsel_new_menu._items = {}
		MenuHelper.menus[gradselreborn.gradsel_main_menu .. "_" .. k] = gradsel_new_menu
	end
end)

function create_random_cg_table()
    create_new_color_grading_table()
    for k, v in pairs(tweak_data.color_grading) do
        gradselreborn.override_all_value[k] = v.text_id
		gradselreborn.override_all[k] = v.value
    end
    return gradselreborn.override_all,gradselreborn.override_all_value
end

Hooks:Add("MenuManagerPopulateCustomMenus", "PopulateCustomMenus_gradselRandomTable", function(menu_manager, nodes)
	MenuCallbackHandler.gradsel_selected_random = function(self, item)
		gradselreborn.options.random_table[item:name()] = (item:value() == "on") or nil
		gradselreborn:Save()
	end
	
	gradselreborn:Load()
	
	for k, v in pairs(create_random_cg_table()) do
		local random_cg_prefix = "" 
        local random_cg = v
		local antidrm = random_cg:gsub('[.].-$', ''):gsub('^[0-9]-color_TdlQ_', '')
		local transform = "color_TdlQ_" .. antidrm
		if string.match(random_cg, "color_TdlQ_") then
			random_cg_prefix = antidrm:gsub('_', ' ') .. ' [TdlQ]'
		elseif string.match(random_cg, "color_") then
			random_cg_prefix = "menu_" .. random_cg
		end
		if managers.localization:exists("menu_" .. random_cg) then
			random_cg_prefix = managers.localization:text("menu_" .. random_cg)
		end
		MenuHelper:AddToggle({
			id = random_cg,
			title = random_cg_prefix,
			desc = "Select the color gradings you want to appear in the random selection table",
			callback = "gradsel_selected_random",
			menu_id = gradselreborn.random_table_menu1,
			value = gradselreborn.options.random_table[random_cg] or false,
			localized = false
		})
	end
end)

Hooks:Add("MenuManagerBuildCustomMenus", "gradsel_buildmenus", function( menu_manager, nodes )
	MenuHelper:AddButton({
		id 			= "gradselID_Reset_all",
		title 		= "gradsel_Reset_all",
		desc 		= "gradselDesc_Resetall",
		callback 	= "GDS_Config_Reset",
		menu_id 	= gradselreborn.gradsel_main_menu,
		priority 	= 101,
		localized	= true
	})

	MenuHelper:AddMultipleChoice( {
		id 			= "gradselID_menu_cg",
		title 		= "gradsel_menu_cg",
		desc 		= "gradselDesc_menu_cg",
		callback 	= "GFCReborn_ValueSet_Menu",
		items 		= create_color_grading_table(),
		menu_id 	= gradselreborn.gradsel_main_menu,
		value 		= gradselreborn.options.menu_color_grading or 15,
		priority 	= 100,
		localized	= true
	})
	
	MenuHelper:AddMultipleChoice( {
		id 			= "gradselID_override",
		title 		= "gradsel_override",
		desc 		= "gradselDesc_override",
		callback 	= "GFCReborn_ValueSet",
		items 		= create_color_grading_table(),
		menu_id 	= gradselreborn.gradsel_main_menu,
		value 		= gradselreborn.options[ "override" ] or 1,
		priority 	= 99,
		localized	= true
	})
	
	MenuHelper:AddDivider({ id = "gradselID_divider_main", size = 20, menu_id = gradselreborn.gradsel_main_menu, priority = 98 })
	
	for level_id , name_id in pairs( gradselreborn.levels ) do
		local contract	= GDSGetTableValue(gradselreborn.levels_data[ level_id ],"contact") or "unknow"
		local menu_id 	= gradselreborn.gradsel_main_menu .. "_" .. contract
		
		gradselreborn.GDScontracts[contract] = true
		
		MenuHelper:AddMultipleChoice( {
			id 			= "gradselID_" 		.. level_id,
			title 		= "gradsel_" 		.. level_id,
			desc 		= "gradselDesc_" 	.. level_id,
			callback 	= "GFCReborn_ValueSet",
			items 		= create_color_grading_table(),
			menu_id 	= menu_id,
			value 		= gradselreborn.options[ level_id ] or 1,
			localized	= true
		} )
	end
	
	nodes[gradselreborn.gradsel_main_menu] = 
		MenuHelper:BuildMenu	( gradselreborn.gradsel_main_menu, { area_bg = "none" , back_callback = "GDS_Close_Options" } )  
		MenuHelper:AddMenuItem	( nodes.blt_options, gradselreborn.gradsel_main_menu, "gradsel_menuTitle", "gradsel_menuDesc")
	
	for k , v in pairs( gradselreborn.GDScontracts ) do
		if v == true then
			local menu_id = gradselreborn.gradsel_main_menu .. "_" .. k
			
			MenuHelper:AddButton({
				id 			= "gradselID_Reset_" 	.. k,
				--title 		= "gradsel_Reset_" 		.. k,
				--desc 		= "gradselDesc_Reset_" 	.. k,
				title 		= "gradsel_Reset_all",
				desc 		= "gradselDesc_Resetall",
				callback 	= "GDS_Config_Reset",
				menu_id 	= menu_id,
				priority 	= 100,
				localized	= true
			})
			
			MenuHelper:AddDivider({ id = "gradselID_divider_" .. k, size = 20, menu_id = menu_id,priority = 99 })
			
			nodes[menu_id] = 
			MenuHelper:BuildMenu	( menu_id, { area_bg = "half" } )  
			MenuHelper:AddMenuItem	( nodes[gradselreborn.gradsel_main_menu], menu_id, menu_id, "gradsel_menuDesc")
		end
	end
	local menu_id1 = gradselreborn.random_table_menu1
	-- if not menu_id1 then
	nodes[menu_id1] = 
			MenuHelper:BuildMenu	( menu_id1, { area_bg = "half" } )  
			MenuHelper:AddMenuItem	( nodes[gradselreborn.gradsel_main_menu], menu_id1, "random_blacklist", "random_blacklist_desc")
	-- end
end)

--------------------------------------------------------------------------------------------------------------

Hooks:Add( "LocalizationManagerPostInit" , "gradselLocalization" , function( self )
	self:add_localized_strings({
		["gradsel_menuTitle"] 			= "Gradient Filter Changer Reborn"
	   ,["gradsel_menuDesc"] 			= "Change menu, camera and in heist color grading"
	   
	   ,["menu_color_off"] 			= "Default"
	   ,["menu_color_default"] 		= "Random"

	   ,["menu_color_matrix"] = "The Matrices"
	   
	   ,["gradsel_main_menu_unknow"]		= "Unknown Contracts"
	   ,["gradsel_Reset_all"]			= "Reset All DayNight"
	   ,["gradselDesc_Resetall"]		= "set all to default"
	   ,["gradsel_override"]			= "Heist Override"
	   ,["gradselDesc_override"]		= "This option will override all heist's color gradings\nUnless set it to default."
	   ,["gradsel_menu_cg"] = "Menu Color Grading"
	   ,["gradselDesc_menu_cg"] = "Select the color grading for the main menu"
	   ,["random_blacklist"] = "Random Color Grading List"
	   ,["random_blacklist_desc"] = "Select the color gradings you want to appear in the random selection table"
   })

	if not NoArmorColorGrading then
		self:add_localized_strings({
			["menu_color_sin"]	= "Gensec"
		})
	end

	for job_id , v in pairs( tweak_data.narrative.jobs ) do 
		for i , job_id2 in pairs( tweak_data.narrative.jobs[job_id].job_wrapper or {} ) do
			if tweak_data.narrative.jobs[ job_id2 ].name_id == nil then 
				GDSParseJob({ tables = tweak_data.narrative.jobs[job_id2].chain or {} , job_id = job_id })
			end
		end
	end
	
	for job_id , v in pairs( tweak_data.narrative.jobs ) do 
		GDSParseJob({ tables = tweak_data.narrative.jobs[job_id].chain or {} , job_id = job_id })
	end

	local 	CustomLoaded = 0
		for i , level_id in pairs( tweak_data.levels._level_index ) do
			-- Get levels id
			if 		tweak_data.levels[ level_id ] 
			and 	tweak_data.levels[ level_id ].name_id 
			--and not self[ level_id ].env_params 
			then	gradselreborn.levels[ level_id ] = tweak_data.levels[ level_id ].name_id end
		end
	
	gradselSet()
   
   for k , v in pairs( tweak_data.narrative.contacts ) do 
	   self:add_localized_strings({ [gradselreborn.gradsel_main_menu .. "_" .. k] = k:gsub('_', ' ') .. " Contracts" })
   end
   
   for level_id , name_id in pairs( gradselreborn.levels ) do 
	   if gradselreborn.levels_data[ level_id ] then
		   local job_name_id 	= gradselreborn.levels_data[ level_id ].job_name_id 	or ""
		   local stage			= gradselreborn.levels_data[ level_id ].stage			or 0
		   local LocText		= level_id
		   local LocTextFull	= self:text(job_name_id)
		   
		   if Localizer:exists(Idstring(job_name_id)) then LocText = Localizer:lookup(Idstring(job_name_id)) end
		   LocText = LocText .. " [" .. stage .. "]"
		   
		   self:add_localized_strings({ 
				["gradsel_"		.. level_id] = LocText
			   ,["gradselDesc_" 	.. level_id] = level_id .. " :level_id\n" .. LocTextFull
		   }) 
		   
		   --log("/ " .. level_id .. " //* " .. tostring(job_name_id) .. " */ " .. LocText)
	   else
		   self:add_localized_strings({ 
				["gradsel_"		.. level_id] = level_id .. " [?]"
			   ,["gradselDesc_" 	.. level_id] = level_id .. " : unknow"
		   }) 
	   end
   end
end )

--------------------------------------------------------------------------------------------------------------