core:module("CoreEnvironmentFeeder")
core:import("CoreClass")
core:import("CoreCode")
core:import("CoreEngineAccess")

if not Global.load_level then
    return
end
local level_id = Global.game_settings.level_id

WorldOverlayTextureFeeder = WorldOverlayTextureFeeder or CoreClass.class(StringFeeder)

local WorldOverlayTextureFeeder_apply = WorldOverlayTextureFeeder.apply
function WorldOverlayTextureFeeder:apply(handler, viewport, scene)
    WorldOverlayTextureFeeder_apply(self, handler, viewport, scene)
    if level_id == "jerry" then -- Birth of Sky
        managers.global_texture:set_texture("current_global_world_overlay_texture", "units/pd2_dlc_jerry/terrain/jry_terrain_df", "texture")
    elseif level_id == "peta2" then -- Goat Simulator Day 2
        managers.global_texture:set_texture("current_global_world_overlay_texture", "environments/world_textures/peta/pta_terrain_overlay_df", "texture")
    elseif level_id == "ranc" then -- MidLand Ranch
        managers.global_texture:set_texture("current_global_world_overlay_texture", "units/pd2_dlc_ranc/architecture/ext/ranc_ext_ground/ranc_terrain_playable_df", "texture")
    elseif level_id == "trai" then -- Lost In Transit
        managers.global_texture:set_texture("current_global_world_overlay_texture", "units/pd2_dlc_trai/architecture/ext/ext_textures/ground/trai_ext_ground_terrain_df", "texture")
    end
end

WorldOverlayMaskTextureFeeder = WorldOverlayMaskTextureFeeder or CoreClass.class(StringFeeder)

local WorldOverlayMaskTextureFeeder_apply = WorldOverlayMaskTextureFeeder.apply
function WorldOverlayMaskTextureFeeder:apply(handler, viewport, scene)
	WorldOverlayMaskTextureFeeder_apply(self, handler, viewport, scene)
    if level_id == "jerry" then -- Birth of Sky
        managers.global_texture:set_texture("global_world_overlay_mask_texture", "units/pd2_dlc_jerry/terrain/jry_terrain_weight_df", "texture")
    elseif level_id == "peta2" then -- Goat Simulator Day 2
        managers.global_texture:set_texture("global_world_overlay_mask_texture", "environments/world_textures/peta/pta_terrain_weight_df", "texture")
    elseif level_id == "ranc" then -- MidLand Ranch
        managers.global_texture:set_texture("global_world_overlay_mask_texture", "units/pd2_dlc_ranc/architecture/ext/ranc_ext_ground/ranc_terrain_playable", "texture")
    elseif level_id == "trai" then -- Lost In Transit
        managers.global_texture:set_texture("global_world_overlay_mask_texture", "units/pd2_dlc_trai/architecture/ext/ext_textures/ground/trai_ext_ground_terrain", "texture")
    end
end