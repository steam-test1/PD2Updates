Hooks:PostHook(HUDBlackScreen, "init", "veritas_apply", function(self, hud)
    veritasreborn:Load()
    VeritasSet()
    for i , level_id in pairs( tweak_data.levels._level_index ) do 
        if veritasreborn.override_all[ veritasreborn.options[ level_id ] ] then
        managers.worlddefinition:_set_environment(veritasreborn.override_all[ veritasreborn.options[ level_id ] ] )
        end
    end
    managers.environment_controller:refresh_render_settings()
end)