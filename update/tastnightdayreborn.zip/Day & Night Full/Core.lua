function TastNightDayReborn:init()
    
end